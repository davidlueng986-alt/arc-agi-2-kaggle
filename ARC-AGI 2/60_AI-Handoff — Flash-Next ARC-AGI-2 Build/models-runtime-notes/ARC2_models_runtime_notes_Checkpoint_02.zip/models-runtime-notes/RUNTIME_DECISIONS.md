# Runtime decisions and evidence

27B first: official BF16 architecture Qwen3_5, four L4 tensor parallel, eager debug path. Original Kaggle mirror is compressed44GB; do not mistake that for uncompressed VRAM. First actual GPU allocation confirmed4x L4 each23034MiB, but Python3.13 could not satisfy cp312 dependencies, so no model measurement resulted.

Flash primary: Intel AutoRound W4A16 backbone (attention/hyperconnections/router-sensitive projections remain higher precision) plus RadixArk FP8 PLE. Kaggle mirror version1 is124.83GB including51.2GB PLE in host memory, roughly73.6GB other stored weights. Storage arithmetic is not a peak-memory guarantee: per-device partitioning, Marlin repacking buffers, activation peaks, PLE registration and KV/mamba states still require real measurement. FP8 PLE dtype is explicitly float8_e4m3fn in text_config; vLLM0.30 source selects the FP8 lookup path before generic quantization checks. Use explicit gptq_marlin and cpu_offload=true. No native NVFP4 compute assumed on Ada.

vLLM0.27.1 cannot run Qwen4Exp (registry inspected). vLLM0.30.0 is selected and pinned by OCI manifest; Python3.12 standalone handles the newer host interpreter. SHA256-check each OCI layer and the interpreter before extraction. Extract to /tmp, never over host libraries. CPU preflight must prove Torch import and dependency versions before GPU.

Context:32768, one/few sequences, eager first to avoid CUDA graph startup cost. Task input examples and current program+counterexample retained; old repair turns compacted. Output thinking budget8192 for validation,16384 xhigh for provisional full inference. Reasoning quality after quantization is UNMEASURED until fixed-subset accuracy is available; no KLD-to-ARC score conversion.

Alternative llama.cpp: official ggml-org IQ4_NL102.05GB or Unsloth UD-IQ4_XS93.68GB, CPU per_layer_token_embd, four-way layer tensor split, mmap enabled. Prefer a higher-quality backbone that fits after CPU-table placement over1-bit just to fit aggregate storage. CPU expert offload or smaller quant remains fallback if real measured per-device allocation fails; not yet benchmarked. MTP/speculation are deferred until stable non-speculative outputs are demonstrated.

12h scheduling: reserve startup and finalization; equal initial per-task time shares transfer saved time to later tasks. Candidate roots are independent, repairs bounded, duplicate code/stagnating branches terminate. Production policy remains A1 until ablation evidence supports promotion. These are implementation choices, not a demonstrated performance claim.

Metric caveat: validation arm GPU-hours count attached-device wall time during that arm; total runtime.json includes startup. Evaluate end-to-end efficiency including startup before comparing serving paths. Never report CPU fixture pass rates as Qwen results or an unfinished subset as a full120-task benchmark.
