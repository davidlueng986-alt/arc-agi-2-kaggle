import json
import os
from pathlib import Path
import subprocess
import sys
import time


class Executor:
    def __init__(self, timeout=5, memory_mb=768):
        self.timeout, self.memory_mb = timeout, memory_mb

    def run(self, source, inputs, timeout=None, mode='solve'):
        start = time.monotonic()
        if mode=='solve' and len(inputs)>1:
            results, observations = [], []
            budget=timeout or self.timeout
            for value in inputs:
                remaining=budget-(time.monotonic()-start)
                if remaining<.05:
                    results.append({'error':'timeout','detail':'batch execution deadline'})
                    continue
                item=self.run(source,[value],timeout=remaining)
                if item.get('error'):
                    results.append({'error':item['error'],'detail':item.get('detail','')})
                else:results.extend(item['results'])
                observations.append(item.get('stdout',''))
            return {'results':results,'stdout':'\n'.join(observations)[:8192],
                    'seconds':time.monotonic()-start,'sandbox':'one-seccomp-process-per-grid'}
        if len(source) > 100000:
            return {'error': 'source_too_long', 'seconds': 0}
        env = {'PATH': '/usr/bin:/bin', 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
               'MKL_NUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1'}
        payload = {'source': source, 'inputs': inputs, 'memory_mb': self.memory_mb,
                   'cpu_seconds': max(1, int(timeout or self.timeout)), 'mode': mode}
        try:
            cp = subprocess.run([sys.executable, '-I', str(Path(__file__).with_name('worker.py'))],
                                input=json.dumps(payload), capture_output=True, text=True, env=env,
                                timeout=max(.05, timeout or self.timeout), close_fds=True, cwd='/tmp',
                                start_new_session=True)
            if cp.returncode:
                result = {'error': 'worker_exit', 'returncode': cp.returncode, 'detail': cp.stderr[-500:]}
            else:
                result = json.loads(cp.stdout)
        except subprocess.TimeoutExpired:
            result = {'error': 'timeout'}
        except (ValueError, OSError) as exc:
            result = {'error': 'executor_error', 'detail': str(exc)[:500]}
        return dict(result, seconds=time.monotonic() - start)
