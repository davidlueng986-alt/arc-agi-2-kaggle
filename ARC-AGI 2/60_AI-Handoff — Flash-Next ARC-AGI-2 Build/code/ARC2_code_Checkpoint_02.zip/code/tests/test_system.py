import json
from pathlib import Path
import tempfile
import unittest
from arcsolver.data import clean_task, fixed_subset, grid
from arcsolver.executor import Executor
from arcsolver.verifier import verify
from arcsolver.search import Solver, SearchConfig, select
from arcsolver.model import ReplayModel, extract_program
from arcsolver.evaluate import metrics, run_evaluation, validate_submission

TASK={'train':[{'input':[[1,2],[3,4]],'output':[[2,1],[4,3]]},
               {'input':[[5,6,7]],'output':[[7,6,5]]}],
      'test':[{'input':[[8,0]],'output':[[0,8]]}]}
WRONG='```python\ndef solve(g): return g\n```'
RIGHT='```python\ndef solve(g): return [row[::-1] for row in g]\n```'


class SystemTests(unittest.TestCase):
    def test_label_firewall(self):
        self.assertNotIn('output',clean_task(TASK)['test'][0])
        with tempfile.TemporaryDirectory() as d:
            Solver(ReplayModel([RIGHT]),Executor(),SearchConfig(candidates=1,repairs=0)).solve('x',TASK,d)
            self.assertNotIn('"output": [[0, 8]]',Path(d,'x','calls.json').read_text())

    def test_exact_verifier_not_cell_similarity(self):
        e=Executor().run('def solve(g): return g',[p['input'] for p in TASK['train']])
        v=verify(e,TASK['train']);self.assertFalse(v['exact']);self.assertEqual(v['fit'],0)
        self.assertEqual(v['pairs'][0]['wrong_cells'],4)

    def test_repair_end_to_end_and_lineage(self):
        with tempfile.TemporaryDirectory() as d:
            s=Solver(ReplayModel([WRONG,RIGHT]),Executor(),SearchConfig(candidates=1,repairs=1))
            r=s.solve('x',TASK,d)
            self.assertTrue(r['train_exact']);self.assertEqual(r['repair_iterations'],1)
            self.assertEqual(r['archive'][1]['parent'],r['archive'][0]['id'])
            self.assertEqual(r['predictions'][0]['attempt_1'],[[0,8]])
            m=metrics([r],{'x':[[[0,8]]]})
            self.assertEqual(m['public_eval_pass_at_1'],1)
            self.assertIsNone(m['gpu_device_hours'])

    def test_file_network_process_isolation(self):
        for expression in ["open('/etc/passwd').read()", "__import__('socket').socket()", "__import__('os').fork()"]:
            e=Executor().run('def solve(g): return '+expression,[[[1]]])
            self.assertFalse(e.get('error')=='sandbox_unavailable',e)
            self.assertIn(e['results'][0]['error'],['PermissionError','ImportError','OSError'])

    def test_timeout(self):
        e=Executor().run('def solve(g):\n while True: pass',[[[1]]],timeout=.5)
        self.assertEqual(e['error'],'timeout')

    def test_malformed_outputs(self):
        for literal in ['[[1.0]]','[[True]]','[[10]]','[]','[[1],[1,2]]']:
            e=Executor().run('def solve(g): return '+literal,[[[1]]])
            self.assertEqual(e['results'][0]['error'],'ValueError')

    def test_independent_state(self):
        src='counter=0\ndef solve(g):\n global counter\n counter+=1\n return [[counter]]'
        e=Executor().run(src,[[[0]],[[0]]])
        self.assertEqual([p['output'] for p in e['results']],[[[1]],[[1]]])
        src='def solve(g):\n np._arc_counter=getattr(np,"_arc_counter",0)+1\n return [[np._arc_counter]]'
        e=Executor().run(src,[[[0]],[[0]]])
        self.assertEqual([p['output'] for p in e['results']],[[[1]],[[1]]])

    def test_shape_feedback(self):
        e=Executor().run('def solve(g): return [[0]]',[[[1,2]]])
        v=verify(e,[{'input':[[1,2]],'output':[[2,1]]}]);self.assertEqual(v['pairs'][0]['expected_shape'],[1,2])

    def test_code_parser_ignores_thinking(self):
        self.assertEqual(extract_program('<think>```python\nbad\n```</think>'+RIGHT),'def solve(g): return [row[::-1] for row in g]')
        with self.assertRaises(ValueError):extract_program('<think>```python\nbad\n```</think>')

    def test_diverse_selection_and_no_repair_vote_inflation(self):
        def c(root,out,exact=True):
            return {'root':root,'outputs':[out],'complexity':4,'verification':{'exact':exact,'fit':int(exact),'cell_accuracy':int(exact)}}
        pool=[c(0,[[1]])]*5+[c(1,[[2]]),c(2,[[2]]),c(3,[[3]],False)]
        p=select(pool,clean_task(TASK))[0]
        self.assertEqual(p['attempt_1'],[[2]]);self.assertEqual(p['attempt_2'],[[1]])

    def test_subset_no_label_dependence(self):
        tasks={str(i):clean_task(TASK) for i in range(20)}
        self.assertEqual(fixed_subset(tasks,8),fixed_subset(tasks,8))
        self.assertEqual(len(set(fixed_subset(tasks,8))),8)

    def test_duck_exploration(self):
        with tempfile.TemporaryDirectory() as d:
            m=ReplayModel([json.dumps({'action':'explore','code':'print(len(TASK["train"]))'}),RIGHT])
            r=Solver(m,Executor(),SearchConfig(mode='duck',candidates=1,repairs=0)).solve('x',TASK,d)
            self.assertTrue(r['train_exact']);self.assertEqual(r['model_calls'],2)

    def test_evaluation_partial_denominator_and_submission(self):
        with tempfile.TemporaryDirectory() as d:
            s=Solver(ReplayModel([RIGHT]),Executor(),SearchConfig(candidates=1,repairs=0))
            tasks={'x':clean_task(TASK)}
            m=run_evaluation(tasks,{'x':[[[0,8]]]},s,d,30)
            self.assertEqual(m['scheduled_public_eval_pass_at_2'],1)
            self.assertTrue(validate_submission(json.loads(Path(d,'submission.json').read_text()),tasks))


if __name__=='__main__':unittest.main()
