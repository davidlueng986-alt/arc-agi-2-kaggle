import json
import re
import time
import urllib.request
import urllib.error
import urllib.parse
import http.client

SYSTEM = '''Infer a single coherent transformation from the ARC demonstrations.
Colours are integer labels 0..9. Do not memorize examples, task IDs or expected test outputs.
Reason about objects, relations and the rule, then implement deterministic Python.
Return the complete program in one final ```python block, defining solve(grid) -> list[list[int]].
The program must work on every training input and on unseen inputs. Helpers are allowed.
Available imports: numpy, math, itertools, functools, collections. np is preloaded.
No filesystem, network, subprocesses or external packages. Grids are at most 30x30.
Do not run tests at module scope; only define functions, constants and imports.'''

DUCK_SYSTEM = SYSTEM + '''
You may first explore with generic Python: return JSON {"action":"explore","code":"..."}.
An exploration is a fresh process, with TASK as a Python dict containing demonstrations and test INPUTS.
Use print for bounded observations. After feedback, emit the final solve program.
Temporary helper state does not persist, so include all final helpers in your program.'''


def extract_program(text):
    # Reasoning-channel code is never promoted to the final candidate.
    text = text.rsplit('</think>', 1)[-1]
    matches = re.findall(r'```(?:python|py)?\s*\n(.*?)```', text, flags=re.S)
    if matches:
        return matches[-1].strip()
    if text.lstrip().startswith(('def ', 'import ', 'from ')) and 'def solve(' in text:
        return text.strip()
    raise ValueError('no complete final Python block')


def extract_action(text):
    text=text.rsplit('</think>',1)[-1].strip()
    fenced=re.findall(r'```json\s*\n(.*?)```',text,flags=re.S)
    try:
        action=json.loads(fenced[-1] if fenced else text)
        return action if isinstance(action,dict) else {}
    except ValueError:return {}


class OpenAIModel:
    """OpenAI-compatible local server. Actual response, usage and stop reason are archived."""
    def __init__(self, url='http://127.0.0.1:8000/v1', model='arc-model', max_tokens=8192,
                 temperature=1.0, reasoning_effort='medium', backend='llama', seed=0,
                 count_context=True, stream=False, thinking_token_budget=None):
        self.url, self.model = url.rstrip('/'), model
        self.max_tokens, self.temperature = max_tokens, temperature
        self.effort, self.backend, self.seed = reasoning_effort, backend, seed
        self.count_context=count_context
        self.stream=stream
        if thinking_token_budget is not None and (type(thinking_token_budget) is not int or thinking_token_budget<0):
            raise ValueError('thinking_token_budget must be a nonnegative integer')
        self.thinking_token_budget=thinking_token_budget

    def generate(self, messages, remaining):
        start=time.monotonic();deadline=start+remaining
        if remaining<=0:raise TimeoutError('model deadline already exhausted')
        body = {'model': self.model, 'messages': messages, 'max_tokens': self.max_tokens,
                'temperature': self.temperature, 'top_p': .95, 'seed': self.seed}
        if self.backend == 'llama':
            body['chat_template_kwargs'] = {'reasoning_effort': self.effort, 'enable_thinking': True}
        else:
            body['chat_template_kwargs'] = {'reasoning_effort': self.effort, 'enable_thinking': True}
            body['reasoning_effort'] = self.effort
            body['top_k'] = 20
        budget={}
        if self.backend=='vllm' and self.count_context:
            # Count the actual chat template, without dropping demonstrations or
            # using test labels to choose examples. /tokenize is outside /v1.
            base=self.url[:-3] if self.url.endswith('/v1') else self.url
            tok={'model':self.model,'messages':messages,'add_generation_prompt':True,
                 'chat_template_kwargs':body['chat_template_kwargs']}
            req=urllib.request.Request(base+'/tokenize',data=json.dumps(tok).encode(),
                                       headers={'Content-Type':'application/json'})
            try:
                with urllib.request.urlopen(req,timeout=max(.1,min(10,deadline-time.monotonic()))) as r:
                    counts=json.load(r)
                count,limit=int(counts['count']),int(counts['max_model_len'])
                available=limit-count-32
                if available<256:raise ValueError(f'context budget exhausted: prompt={count}, context={limit}')
                body['max_tokens']=min(self.max_tokens,available)
                budget={'prompt_tokens':count,'context_limit':limit,
                        'requested_max_tokens':self.max_tokens,'effective_max_tokens':body['max_tokens']}
            except urllib.error.HTTPError as exc:
                if exc.code not in (404,405):raise
                budget={'tokenize_endpoint_unavailable':exc.code}
        if deadline-time.monotonic()<=0:raise TimeoutError('model tokenization exhausted deadline')
        if self.thinking_token_budget is not None:
            if self.backend!='vllm':raise ValueError('thinking budget is validated only against vLLM protocol')
            body['thinking_token_budget']=min(self.thinking_token_budget,max(0,body['max_tokens']-512))
            budget['effective_thinking_token_budget']=body['thinking_token_budget']
        if self.stream:return self._stream_request(body,deadline,start,budget)
        req = urllib.request.Request(self.url + '/chat/completions', data=json.dumps(body).encode(),
                                     headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=max(.1, min(deadline-time.monotonic(), 600))) as r:
                raw = json.load(r)
        except urllib.error.HTTPError as exc:
            detail=exc.read(4096).decode(errors='replace')
            raise RuntimeError(f'local model HTTP {exc.code}: {detail}') from exc
        choice = raw['choices'][0]
        return {'text': choice['message'].get('content') or '',
                'reasoning': choice['message'].get('reasoning_content') or choice['message'].get('reasoning') or '',
                'finish_reason': choice.get('finish_reason'), 'usage': raw.get('usage', {}),
                'seconds': time.monotonic()-start, 'model': raw.get('model', self.model),
                'token_budget':budget}

    def _stream_request(self,body,deadline,start,budget):
        """Optional SSE collection preserves partial evidence at a wall deadline.
        It is not enabled by existing A1/A4 configurations or the frozen GPU run.
        """
        target=urllib.parse.urlsplit(self.url+'/chat/completions')
        cls=http.client.HTTPSConnection if target.scheme=='https' else http.client.HTTPConnection
        conn=cls(target.hostname,target.port,timeout=max(.1,deadline-time.monotonic()))
        body=dict(body,stream=True,stream_options={'include_usage':True})
        text,reasoning,usage=[],[],{};finish=None;model=self.model;chunks=0;chars=0;response=None
        try:
            conn.request('POST',target.path,json.dumps(body),{'Content-Type':'application/json'})
            response=conn.getresponse()
            if response.status>=400:
                raise RuntimeError(f'local model HTTP {response.status}: '+response.read(4096).decode(errors='replace'))
            while True:
                remaining=deadline-time.monotonic()
                if remaining<=0:finish='deadline';break
                if conn.sock is not None:conn.sock.settimeout(max(.01,remaining))
                line=response.readline(1048577)
                if not line:break
                if len(line)>1048576:finish='response_limit';break
                if not line.startswith(b'data:'):continue
                value=line[5:].strip()
                if value==b'[DONE]':break
                data=json.loads(value);chunks+=1;model=data.get('model',model)
                if data.get('usage'):usage=data['usage']
                for choice in data.get('choices',[]):
                    delta=choice.get('delta') or {}
                    a=delta.get('content') or '';b=delta.get('reasoning_content') or delta.get('reasoning') or ''
                    chars+=len(a)+len(b)
                    if chars>1048576:finish='response_limit';break
                    text.append(a);reasoning.append(b)
                    if choice.get('finish_reason'):finish=choice['finish_reason']
                if finish=='response_limit':break
        except TimeoutError:finish='deadline'
        finally:
            if response is not None:response.close()
            conn.close()
        return {'text':''.join(text),'reasoning':''.join(reasoning),'usage':usage,
                'finish_reason':finish or 'connection_closed','seconds':time.monotonic()-start,
                'model':model,'token_budget':budget,'stream_chunks':chunks,
                'partial_generation':finish in (None,'deadline','response_limit')}


class ReplayModel:
    """Deterministic fixture provider for infrastructure tests ONLY; never model evidence."""
    def __init__(self, responses):
        self.responses = iter(responses)

    def generate(self, messages, remaining):
        return {'text': next(self.responses), 'seconds': 0, 'finish_reason': 'stop',
                'usage': {}, 'model': 'FIXTURE-NOT-QWEN'}
