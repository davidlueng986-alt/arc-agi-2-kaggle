"""CPU-only audit of real archived results against the exact public data revision."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parents[1]))
from arcsolver.data import load_tasks, digest
from arcsolver.evaluate import atomic_json


def analyze(run, tasks_path, labels_path, arm='A1'):
    run=Path(run)
    tasks,_=load_tasks(tasks_path);labels=json.loads(Path(labels_path).read_text())
    runtime=json.loads((run/'runtime.json').read_text())
    rows=[];failures=Counter();tokens=Counter();generation_seconds=0
    for f in sorted((run/arm/'traces').glob('*/result.json')):
        r=json.loads(f.read_text());task=tasks[r['task_id']]
        if digest(task)!=r['task_hash']:
            raise ValueError('benchmark input revision differs: '+r['task_id'])
        truth=labels[r['task_id']];fits=[c for c in r['archive'] if c['verification']['exact']]
        verified_full=any(c.get('outputs')==truth for c in fits)
        p=r['predictions']
        if len(p)!=len(truth) or len(truth)!=len(task['test']):
            raise ValueError('test-output count differs: '+r['task_id'])
        calls=json.loads(f.with_name('calls.json').read_text())
        for c in calls:
            if 'text' in c:
                generation_seconds+=c.get('seconds',0)
                for k,v in c.get('usage',{}).items():
                    if isinstance(v,(int,float)):tokens[k]+=v
        failures.update(r['failures'])
        rows.append({'task_id':r['task_id'],'train_fit':bool(fits),
            'test_outputs':len(truth),
            'correct_attempt1_outputs':sum(x['attempt_1']==g for x,g in zip(p,truth)),
            'correct_attempt2_union_outputs':sum(g in (x['attempt_1'],x['attempt_2']) for x,g in zip(p,truth)),
            'all_outputs_pass_at_1':all(x['attempt_1']==g for x,g in zip(p,truth)),
            'all_outputs_pass_at_2':all(g in (x['attempt_1'],x['attempt_2']) for x,g in zip(p,truth)),
            'one_verified_program_correct_for_all_test_outputs':verified_full,
            'seconds':r['seconds'],'proposals':sum('text' in c and 'exploration' not in c for c in calls),
            'model_calls':len(calls),'repairs':r['repair_iterations']})
    n=len(rows);outputs=sum(r['test_outputs'] for r in rows)
    fitted=sum(r['train_fit'] for r in rows);correct=sum(r['one_verified_program_correct_for_all_test_outputs'] for r in rows)
    hours=runtime.get('elapsed_seconds',0)*len(runtime.get('gpus',[]))/3600
    return {'source_sha256':runtime['run']['source_sha256'],'arm':arm,
        'benchmark_task_hash':digest(tasks),'labels_sha256':__import__('hashlib').sha256(Path(labels_path).read_bytes()).hexdigest(),
        'completed_tasks':n,'completed_test_outputs':outputs,
        'public_eval_output_pass_at_1':sum(r['correct_attempt1_outputs'] for r in rows)/outputs if outputs else None,
        'public_eval_output_pass_at_2':sum(r['correct_attempt2_union_outputs'] for r in rows)/outputs if outputs else None,
        'task_all_outputs_pass_at_1':sum(r['all_outputs_pass_at_1'] for r in rows)/n if n else None,
        'task_all_outputs_pass_at_2':sum(r['all_outputs_pass_at_2'] for r in rows)/n if n else None,
        'verified_correct_whole_tasks':correct,
        'train_fit_to_whole_task_generalization':correct/fitted if fitted else None,
        'end_to_end_gpu_device_hours':hours or None,
        'correct_verified_tasks_per_gpu_device_hour':correct/hours if hours and n else None,
        'usage_totals':dict(tokens),'request_wall_seconds':generation_seconds,
        'completion_tokens_per_request_wall_second':tokens['completion_tokens']/generation_seconds if generation_seconds else None,
        'failure_categories':dict(failures),'rows':rows,
        'caveats':['These are completed-task denominators; compare saved metrics.json for scheduled denominators.',
                   'Whole-task verified correctness requires one train-fitting program to match every test output.',
                   'Request wall throughput includes tokenization/HTTP/prefill, not decode-only speed.',
                   'Small fixed subsets do not establish full120 accuracy or architectural gains.']}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--tasks',required=True)
    p.add_argument('--labels',required=True);p.add_argument('--arm',default='A1');p.add_argument('--out',required=True)
    a=p.parse_args();r=analyze(a.run,a.tasks,a.labels,a.arm);atomic_json(a.out,r)
    print(json.dumps({k:v for k,v in r.items() if k!='rows'},indent=2))
