# Optional transport/budget experiment, not a promoted solver policy

Pinned vLLM0.30 source exposes thinking_token_budget in ChatCompletionRequest. ReasoningConfig can initialise start/end IDs from the qwen3 reasoning parser. Upstream tests verify forced reasoning termination and mixed budget/no-budget requests; those tests do not prove Flash quality on ARC.

The experimental adapter supports SSE and preserves partial evidence at a wall deadline, including the distinction between reasoning and final content. Default models/configs remain non-streaming with unconstrained thinking inside the total generation cap. The running G04 source is unchanged.

Optional local config:code/configs/A1-stream-thinking-budget-experimental.json. Optional notebook build flags:--stream --thinking-budget 4096. Do not label CPU HTTP fixture success as Flash validation, and do not infer accuracy improvement from upstream API support. A future paired ablation must preserve model/subset/context/wall budgets and report final-code yield, exact fit, held-out accuracy, latency and truncated/deadline responses.

First G04 ARC call:480s with0 candidates. Second:480s with0 candidates. Raw server/call logs pending. These observations motivate better evidence capture; they do not yet identify decode speed, prefill, overthinking, or server queueing as the cause.
