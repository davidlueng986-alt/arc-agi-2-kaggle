# ARC-AGI-2 executable-program induction

Implemented system: ARC loader → model-generated Python → fresh sandbox process per grid → exact all-train verifier → structured counterexamples → bounded repair and independent roots → output diversity selection → atomic submission/evaluation.

Current evidence: harness works; Flash weights load on L4×4, but no real generated solution has yet been recorded. Public-eval pass@1/pass@2, quantization quality and new LB accuracy are **unmeasured**. See RESEARCH_LOG.md and experiments/EXPERIMENT_REGISTER.json. Failed runs are preserved. CPU registration submissions are explicitly labelled placeholders and are not model scores.

## Run locally

Linux, libseccomp.so.2, Python, NumPy2.3.5. Core harness needs no Torch.

```bash
cd code
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m arcsolver.cli --tasks ../references/snapshots/ARC-AGI-2-f3283f727488ad98fe575ea6a5ac981e4a188e49/data/evaluation --config configs/A1-one-program.json --subset 12 --budget 3600 --gpu-count 4 --out ../experiments/local-A1
```

Start a real local OpenAI-compatible model server first (default localhost:8000/v1). Use --tasks with the actual extracted evaluation directory if its snapshot name differs. --subset 0 evaluates the full set. The frozen stratified task manifests are in experiments/public-eval-subset-{4,12,120}.json; seed20261024, no selection using test labels. Report the saved task hash and exact model resource/version with every result.

Compare configs/A1-one-program.json, A4-search-repair.json and duck-generic.json. Optional search/repair/diversity are implemented, but **no model ablation has established a gain**. Duck mode uses bounded generic Python exploration in fresh processes, not a persistent original Duck REPL. Production remains one-program A1 until evidence supports promotion.

## Security and correctness

Every input grid uses a fresh Linux seccomp process; memory/CPU/wall/output limits apply and unsupported isolation fails closed. Workers receive no environment credentials or hidden test labels. Parent revalidates the worker JSON protocol, result count and colour-grid domain. The model sees training outputs and test inputs only. The exact verifier never substitutes cell similarity for a training fit. Archive includes lineage, source dedup, test predictions, structured failure, full model responses, usage and stop reasons.

vLLM calls count the actual chat template through /tokenize and fit completion budget into the context, preserving all examples. Unsupported tokenization endpoints are explicitly logged. Output budget reductions and truncated generations remain visible. HTTP and fixture tests verify protocol only; they are not neural evidence.

## Offline serving inputs

Flash: dfranzen/albucino-qwen3.8-flash-next-w4a16-fp8ple/transformers/default/1; foysalemonshanto/vllm-0-30-0-runtime. 27B: rahim3/qwen3-8-27b-bf16; saltb0x/arc3-vllm-wheelhouse-v0271-cu129. Both attach liangwanyiudavid/arc2-runtime-builder for hash-checked standalone CPython3.12.15. Model-serving ABI is3.12; Kaggle host is3.13. Flash requires Qwen4Exp support in vLLM0.30, not0.27.1.

Flash G03 loaded18.34GiB/rank, peak19651MiB/rank; it failed KV cache admission at32K context (.46GiB available versus .49GiB required). Revised configuration .92 memory utilization, batched prefill512, one sequence, TP4+EP, CPU FP8PLE, eager, 32K context. Correction is not yet proven by inference. See models-runtime-notes/RUNTIME_DECISIONS.md.

## Kaggle workflow and quota

Generated notebooks embed source and its SHA256. Build with scripts/build_notebook.py. Guarded scripts/push_kaggle.py defaults to non-GPU; do not bypass experiments/gpu-budget.json. G01/G02/G03 reserve6900s total, ledger is closed. Observed main durations sum2777.486s; they exclude platform overhead. No new ordinary GPU run is scheduled. --submission-snapshot is a separately audited Quick Save (--no-run) metadata path, never an ordinary execution; its submission eligibility is not yet proven.

Ordinary CPU commits execute tests and produce a schema-valid submission.json for filename registration, with model_inference_performed=false. Competition reruns detected by KAGGLE_IS_COMPETITION_RERUN must actually have L4×4 and generate executable model code; absence of GPU fails explicitly before using a placeholder. Actual accelerator inheritance from a CPU commit is being tested, not assumed. Integration submission57645178 used immutable Flash v7 and failed with an unhandled error; no score or GPU inheritance claim. A v10 L4 metadata Quick Save was confirmed saved without running; submission was not accepted (daily allowance exhausted and output eligibility pending). Later CPU versions do not mutate that running version.

Formal runtime cap42600s reserves600s from12h. Hidden predictions update /kaggle/working/submission.json after each task. Initial per-task shares transfer saved time to remaining tasks. Current provisional production uses xhigh reasoning and up to16384 output tokens; the simple low-effort1024-token row-reversal smoke is only an integration test. These settings have no measured accuracy guarantee.

## Metrics and replay

Exact pass@1/pass@2 are per test output, with completed and scheduled denominators separate. Report exact-train-fit, conditional train→test fit (including test execution failures), correct verified outputs/GPU-device-hour, proposal/unique/archive/duplicate counts, repairs, runtime/VRAM and failure categories. GPU hours sum attached-device hours, not Kaggle quota billing units. Include startup in end-to-end efficiency.

scripts/audit_traces.py performs label-free post-generation audit. scripts/ablate_archives.py compares selection/filter policies on a frozen generated pool; it does not claim equal-generation-budget causal effects. Missing traces mean missing model evidence, not0% accuracy. No full120 public benchmark has completed.

## Reproducibility and provenance

New code MIT-0; sources retain original licences. See references/SOURCE_CATALOG.json and SOURCE_MANIFEST.json. External Kaggle model/runtime bytes are resource/manifest pinned and attached, not duplicated into the ZIP. Downloaded papers, source snapshots, interpreter bytes, prompts/configs, subsets, notebooks, logs and manifests are included. No credentials are packaged.

```bash
python code/scripts/package_checkpoint.py --root . --name ARC2_Build_Checkpoint_04
python code/scripts/verify_checkpoint.py packages/ARC2_Build_Checkpoint_04.zip
```
