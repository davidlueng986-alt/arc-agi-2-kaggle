from pathlib import Path
import urllib.request,json,hashlib
root=Path('/kaggle/working/python312-artifact');root.mkdir(exist_ok=True)
manifest={'publisher': 'astral-sh/python-build-standalone', 'release': '20261021', 'python': '3.12.15', 'source_url': 'https://github.com/astral-sh/python-build-standalone/releases/tag/20261021', 'file': 'cpython-3.12.15+20261021-x86_64-unknown-linux-gnu-install_only.tar.gz', 'sha256': '5ff9f0602ce964a529ed1e8555d3abab6341926d724402ba9a15e9e877191124', 'license': 'Python and bundled dependency licences retained within archive'}
url='https://github.com/astral-sh/python-build-standalone/releases/download/20261021/cpython-3.12.15%2B20261021-x86_64-unknown-linux-gnu-install_only.tar.gz'
data=urllib.request.urlopen(url,timeout=120).read()
assert hashlib.sha256(data).hexdigest()==manifest['sha256']
(root/manifest['file']).write_bytes(data)
(root/'provenance.json').write_text(json.dumps(manifest,indent=2))
print('Pinned offline interpreter prepared:',len(data),'bytes')
