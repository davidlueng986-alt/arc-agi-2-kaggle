import json
import re
import time
import urllib.request
import urllib.error

SYSTEM = '''Infer a single coherent transformation from the ARC demonstrations.
Colours are integer labels 0..9. Do not memorize examples, task IDs or expected test outputs.
Reason about objects, relations and the rule, then implement deterministic Python.
Return the complete program in one final ```python block, defining solve(grid) -> list[list[int]].
The program must work on every training input and on unseen inputs. Helpers are allowed.
Available imports: numpy, math, itertools, functools, collections. np is preloaded.
No filesystem, network, subprocesses or external packages. Grids are at most 30x30.
Do not run tests at module scope; only define functions, constants and imports.'''

DUCK_SYSTEM = SYSTEM + '''
You may first explore with generic Python: return JSON {"action":"explore","code":"..."}.
An exploration is a fresh process, with TASK as a Python dict containing demonstrations and test INPUTS.
Use print for bounded observations. After feedback, emit the final solve program.
Temporary helper state does not persist, so include all final helpers in your program.'''


def extract_program(text):
    # Reasoning-channel code is never promoted to the final candidate.
    text = text.rsplit('</think>', 1)[-1]
    matches = re.findall(r'```(?:python|py)?\s*\n(.*?)```', text, flags=re.S)
    if matches:
        return matches[-1].strip()
    if text.lstrip().startswith(('def ', 'import ', 'from ')) and 'def solve(' in text:
        return text.strip()
    raise ValueError('no complete final Python block')


def extract_action(text):
    text=text.rsplit('</think>',1)[-1].strip()
    fenced=re.findall(r'```json\s*\n(.*?)```',text,flags=re.S)
    try:
        action=json.loads(fenced[-1] if fenced else text)
        return action if isinstance(action,dict) else {}
    except ValueError:return {}


class OpenAIModel:
    """OpenAI-compatible local server. Actual response, usage and stop reason are archived."""
    def __init__(self, url='http://127.0.0.1:8000/v1', model='arc-model', max_tokens=8192,
                 temperature=1.0, reasoning_effort='medium', backend='llama', seed=0,
                 count_context=True):
        self.url, self.model = url.rstrip('/'), model
        self.max_tokens, self.temperature = max_tokens, temperature
        self.effort, self.backend, self.seed = reasoning_effort, backend, seed
        self.count_context=count_context

    def generate(self, messages, remaining):
        start=time.monotonic();deadline=start+remaining
        if remaining<=0:raise TimeoutError('model deadline already exhausted')
        body = {'model': self.model, 'messages': messages, 'max_tokens': self.max_tokens,
                'temperature': self.temperature, 'top_p': .95, 'seed': self.seed}
        if self.backend == 'llama':
            body['chat_template_kwargs'] = {'reasoning_effort': self.effort, 'enable_thinking': True}
        else:
            body['chat_template_kwargs'] = {'reasoning_effort': self.effort, 'enable_thinking': True}
            body['reasoning_effort'] = self.effort
            body['top_k'] = 20
        budget={}
        if self.backend=='vllm' and self.count_context:
            # Count the actual chat template, without dropping demonstrations or
            # using test labels to choose examples. /tokenize is outside /v1.
            base=self.url[:-3] if self.url.endswith('/v1') else self.url
            tok={'model':self.model,'messages':messages,'add_generation_prompt':True,
                 'chat_template_kwargs':body['chat_template_kwargs']}
            req=urllib.request.Request(base+'/tokenize',data=json.dumps(tok).encode(),
                                       headers={'Content-Type':'application/json'})
            try:
                with urllib.request.urlopen(req,timeout=max(.1,min(10,deadline-time.monotonic()))) as r:
                    counts=json.load(r)
                count,limit=int(counts['count']),int(counts['max_model_len'])
                available=limit-count-32
                if available<256:raise ValueError(f'context budget exhausted: prompt={count}, context={limit}')
                body['max_tokens']=min(self.max_tokens,available)
                budget={'prompt_tokens':count,'context_limit':limit,
                        'requested_max_tokens':self.max_tokens,'effective_max_tokens':body['max_tokens']}
            except urllib.error.HTTPError as exc:
                if exc.code not in (404,405):raise
                budget={'tokenize_endpoint_unavailable':exc.code}
        if deadline-time.monotonic()<=0:raise TimeoutError('model tokenization exhausted deadline')
        req = urllib.request.Request(self.url + '/chat/completions', data=json.dumps(body).encode(),
                                     headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=max(.1, min(deadline-time.monotonic(), 600))) as r:
                raw = json.load(r)
        except urllib.error.HTTPError as exc:
            detail=exc.read(4096).decode(errors='replace')
            raise RuntimeError(f'local model HTTP {exc.code}: {detail}') from exc
        choice = raw['choices'][0]
        return {'text': choice['message'].get('content') or '',
                'reasoning': choice['message'].get('reasoning_content') or choice['message'].get('reasoning') or '',
                'finish_reason': choice.get('finish_reason'), 'usage': raw.get('usage', {}),
                'seconds': time.monotonic()-start, 'model': raw.get('model', self.model),
                'token_budget':budget}


class ReplayModel:
    """Deterministic fixture provider for infrastructure tests ONLY; never model evidence."""
    def __init__(self, responses):
        self.responses = iter(responses)

    def generate(self, messages, remaining):
        return {'text': next(self.responses), 'seconds': 0, 'finish_reason': 'stop',
                'usage': {}, 'model': 'FIXTURE-NOT-QWEN'}
