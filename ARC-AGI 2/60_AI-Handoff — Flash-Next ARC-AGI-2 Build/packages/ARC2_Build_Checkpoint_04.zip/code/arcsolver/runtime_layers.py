"""Materialize pinned, hash-checked vLLM OCI layers into an isolated /tmp tree.
No host site-packages or system files are overwritten.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import tarfile


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
    return h.hexdigest()


def materialize(manifest_path,destination):
    manifest_path=Path(manifest_path);destination=Path(destination)
    if sha256(manifest_path)!='20947fbc374e5599d93a0bb31f4bdd2cdba29519f3bc08ee970c3b168863712c':
        raise ValueError('runtime manifest differs from frozen vLLM0.30 checkpoint')
    manifest=json.loads(manifest_path.read_text())
    if manifest.get('image')!='vllm/vllm-openai:v0.30.0':
        raise ValueError('unexpected runtime image')
    allowed=('usr/local/lib/python3.12/dist-packages/','usr/local/cuda-13.0/','usr/local/bin/')
    destination.mkdir(parents=True,exist_ok=True)
    for layer in manifest['selected_layers']:
        path=manifest_path.parent/layer['file']
        if sha256(path)!=layer['sha256']:raise ValueError('runtime layer checksum mismatch: '+path.name)
        with tarfile.open(path,'r|gz') as archive:
            for member in archive:
                name=member.name.lstrip('./')
                pp=PurePosixPath(name)
                if pp.is_absolute() or '..' in pp.parts:raise ValueError('unsafe layer path')
                if not any((name+'/').startswith(prefix) for prefix in allowed):continue
                if '/.wh.' in name:continue
                target=destination/name
                if member.isdir():target.mkdir(parents=True,exist_ok=True);continue
                target.parent.mkdir(parents=True,exist_ok=True)
                # Never follow a previously-created layer symlink when writing.
                if any(p.is_symlink() for p in target.parents if p!=destination and destination in p.parents):
                    raise ValueError('layer parent is symlink: '+name)
                if target.is_symlink() or target.is_file():target.unlink()
                if member.isfile():
                    with archive.extractfile(member) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst,1024**2)
                    target.chmod(member.mode & 0o777)
                elif member.issym() or member.islnk():
                    link=member.linkname
                    if link.startswith('/'):
                        resolved=destination/link.lstrip('/')
                    else:resolved=target.parent/link
                    resolved=resolved.resolve(strict=False)
                    if destination.resolve() not in resolved.parents:raise ValueError('unsafe layer link')
                    if member.issym():target.symlink_to(os.path.relpath(resolved,target.parent))
                    elif resolved.exists():shutil.copyfile(resolved,target)
    site=destination/manifest['layout']['site_packages']
    env=os.environ.copy()
    env['PYTHONPATH']=':'.join([str(destination/p) for p in manifest['layout'].get('pythonpath_prepend',[])]+[str(site)])
    env['CUDA_HOME']=str(destination/manifest['layout']['cuda_home'])
    env['PATH']=str(destination/'usr/local/bin')+':'+str(destination/'usr/local/cuda-13.0/bin')+':'+env.get('PATH','')
    libraries=[destination/manifest['layout']['cuda_lib'],site/'torch/lib']
    libraries+=sorted((site/'nvidia').glob('*/lib'))
    # New NVIDIA namespace bundles cu13 beneath this directory.
    libraries+=sorted((site/'nvidia').glob('cu13/lib'))
    env['LD_LIBRARY_PATH']=':'.join(str(p) for p in libraries if p.is_dir())+':'+env.get('LD_LIBRARY_PATH','')
    env['VLLM_PLE_CPU_OFFLOAD']='1'
    return env,manifest
