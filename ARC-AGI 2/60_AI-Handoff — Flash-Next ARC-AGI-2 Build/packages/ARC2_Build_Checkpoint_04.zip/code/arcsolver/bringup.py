"""Bounded 27B probe inside the already-budgeted Flash validation allocation."""
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import urllib.request
from .data import load_tasks, fixed_subset
from .evaluate import atomic_json, run_evaluation
from .executor import Executor
from .model import OpenAIModel, extract_program
from .search import Solver, SearchConfig


def probe_27b(python, env, inputs, outdir, seconds=900):
    start=time.monotonic();deadline=start+seconds
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    info={'status':'starting','hard_seconds':seconds,'model':'Qwen3.8-27B BF16','runtime':'vLLM0.30.0'}
    proc=None
    try:
        configs=[]
        for p in Path(inputs).rglob('config.json'):
            try:
                if json.loads(p.read_text()).get('model_type')=='qwen3_5':configs.append(p)
            except ValueError:pass
        if not configs:raise RuntimeError('27B probe model not mounted')
        model=sorted(configs)[0].parent
        cmd=[python,'-m','vllm.entrypoints.openai.api_server','--model',str(model),
             '--served-model-name','arc-model','--host','127.0.0.1','--port','8000',
             '--tensor-parallel-size','4','--max-model-len','16384','--max-num-seqs','1',
             '--max-num-batched-tokens','512','--gpu-memory-utilization','0.85',
             '--enforce-eager','--reasoning-parser','qwen3','--language-model-only',
             '--disable-custom-all-reduce','--safetensors-load-strategy','prefetch']
        info['server_command']=cmd;atomic_json(outdir/'runtime.json',info)
        with (outdir/'server.log').open('w') as log:
            proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            ready=False
            while time.monotonic()<deadline-120:
                if proc.poll() is not None:raise RuntimeError('27B probe server exited '+str(proc.returncode))
                try:
                    with urllib.request.urlopen('http://127.0.0.1:8000/v1/models',timeout=2) as r:
                        if r.status==200:ready=True;break
                except Exception:time.sleep(3)
            if not ready:raise RuntimeError('27B bounded probe readiness deadline')
            info['startup_seconds']=time.monotonic()-start
            llm=OpenAIModel(max_tokens=4096,backend='vllm',reasoning_effort='medium')
            smoke=llm.generate([{'role':'user','content':'Return a fenced Python program defining solve(grid) that reverses each row. Keep reasoning brief.'}],
                               min(90,deadline-time.monotonic()-20))
            atomic_json(outdir/'model-smoke.json',smoke)
            evidence=Executor().run(extract_program(smoke['text']),[[[1,2,3]]])
            atomic_json(outdir/'smoke-execution.json',evidence)
            if evidence.get('results')!=[{'output':[[3,2,1]]}]:raise RuntimeError('27B real generated program did not pass smoke')
            info['real_model_smoke_passed']=True
            challenges=list(Path(inputs).rglob('arc-agi_evaluation_challenges.json'))
            if challenges and deadline-time.monotonic()>25:
                tasks,labels=load_tasks(challenges[0])
                lp=challenges[0].with_name('arc-agi_evaluation_solutions.json')
                if lp.exists():labels=json.loads(lp.read_text())
                ids=fixed_subset(tasks,2)[:1];tasks={k:tasks[k] for k in ids}
                budget=min(300,deadline-time.monotonic()-15)
                solver=Solver(llm,Executor(),SearchConfig(candidates=1,repairs=1,task_seconds=budget))
                info['eval']=run_evaluation(tasks,labels,solver,outdir/'evaluation',budget,gpu_count=4)
            info['status']='completed'
    except Exception as exc:
        info['status']='failed';info['error']=type(exc).__name__+': '+str(exc)
        if (outdir/'server.log').exists():print((outdir/'server.log').read_text(errors='replace')[-3500:],flush=True)
    finally:
        if proc:
            try:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=10)
            except (ProcessLookupError,subprocess.TimeoutExpired):
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError:pass
        info['elapsed_seconds']=time.monotonic()-start
        atomic_json(outdir/'runtime.json',info)
        print(json.dumps({'27b_probe':info}),flush=True)
    return info
