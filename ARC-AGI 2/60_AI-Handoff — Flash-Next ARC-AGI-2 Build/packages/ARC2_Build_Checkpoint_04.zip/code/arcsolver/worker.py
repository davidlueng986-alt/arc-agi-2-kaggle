"""One-use Linux worker. Read payload, preload libraries, remove privilege,
then deny filesystem/network/process syscalls before executing generated code.
Fails closed when kernel seccomp is unavailable. Never receives test labels.
"""
import builtins
import collections
import contextlib
import ctypes
import errno
import functools
import io
import itertools
import json
import math
import os
import resource
import sys
import traceback
import numpy as np


class BoundedText(io.StringIO):
    def write(self, s):
        remaining = max(0, 8192 - self.tell())
        super().write(str(s)[:remaining])
        return len(s)


def lock_down(memory_mb, cpu_seconds):
    lib = ctypes.CDLL('libseccomp.so.2', use_errno=True)
    lib.seccomp_init.argtypes = [ctypes.c_uint32]
    lib.seccomp_init.restype = ctypes.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    lib.seccomp_syscall_resolve_name.restype = ctypes.c_int
    lib.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    lib.seccomp_load.argtypes = [ctypes.c_void_p]
    lib.seccomp_release.argtypes = [ctypes.c_void_p]
    resource.setrlimit(resource.RLIMIT_AS, (memory_mb * 1024**2,) * 2)
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 1))
    resource.setrlimit(resource.RLIMIT_FSIZE, (0, 0))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    # Remove all capabilities by changing to nobody before installing filter.
    if os.getuid() == 0:
        try:
            os.setgroups([])
            os.setgid(65534)
            os.setuid(65534)
        except (PermissionError, OSError):
            # Single-user rootless containers do not map UID 65534. Their
            # namespace root is already an unprivileged host UID. Seccomp
            # below is mandatory in both cases and denies privilege changes.
            uid_map = open('/proc/self/uid_map').read().split()
            if len(uid_map) != 3 or int(uid_map[2]) != 1:
                raise RuntimeError('cannot drop UID in a non-rootless container')
    ctx = lib.seccomp_init(0x7fff0000)  # SCMP_ACT_ALLOW
    if not ctx:
        raise RuntimeError('seccomp_init failed')
    denied = '''open openat openat2 creat socket socketpair connect bind listen accept accept4
    sendto sendmsg recvfrom recvmsg execve execveat fork vfork clone clone3 ptrace
    process_vm_readv process_vm_writev mount umount2 pivot_root chroot unshare setns
    unlink unlinkat rename renameat renameat2 mkdir mkdirat rmdir link linkat symlink symlinkat
    truncate ftruncate chmod fchmod fchmodat chown fchown lchown fchownat
    kill tkill tgkill pidfd_open pidfd_send_signal io_uring_setup bpf perf_event_open
    init_module finit_module delete_module reboot kexec_load keyctl add_key request_key
    readlink readlinkat getdents getdents64 name_to_handle_at open_by_handle_at
    memfd_create userfaultfd setuid setgid setresuid setresgid setreuid setregid setgroups
    '''.split()
    for name in denied:
        num = lib.seccomp_syscall_resolve_name(name.encode())
        if num >= 0 and lib.seccomp_rule_add(ctx, 0x00050000 | errno.EPERM, num, 0) != 0:
            raise RuntimeError('seccomp rule failed: ' + name)
    if lib.seccomp_load(ctx) != 0:
        raise RuntimeError('seccomp_load failed')
    lib.seccomp_release(ctx)


def normalize(value):
    if isinstance(value, np.ndarray):
        value = value.tolist()
    # Reject booleans/floats instead of silently rounding invalid predictions.
    if not isinstance(value, list) or not 1 <= len(value) <= 30:
        raise ValueError('invalid grid height')
    if not isinstance(value[0], (list, tuple)) or not 1 <= len(value[0]) <= 30:
        raise ValueError('invalid grid width')
    width = len(value[0])
    out = []
    for row in value:
        if not isinstance(row, (list, tuple)) or len(row) != width:
            raise ValueError('ragged grid')
        r = []
        for c in row:
            if isinstance(c, (bool, np.bool_)) or not isinstance(c, (int, np.integer)) or not 0 <= int(c) <= 9:
                raise ValueError('invalid colour')
            r.append(int(c))
        out.append(r)
    return out


def main():
    payload = json.loads(sys.stdin.read(250000))
    output_stream = sys.stdout
    capture = BoundedText()
    try:
        lock_down(payload.get('memory_mb', 768), payload.get('cpu_seconds', 3))
    except BaseException as exc:
        json.dump({'error': 'sandbox_unavailable', 'detail': str(exc)[:500]}, output_stream)
        return
    scope = {'__builtins__': builtins, 'np': np, 'numpy': np, 'math': math,
             'collections': collections, 'itertools': itertools, 'functools': functools}
    results = []
    with contextlib.redirect_stdout(capture), contextlib.redirect_stderr(capture):
        try:
            if payload.get('mode') == 'explore':
                exec(compile(payload['source'], '<candidate>', 'exec'), scope)
                results = None
            else:
                for g in payload['inputs']:
                    try:
                        # Independent fresh program state for every grid; no pair-index tricks.
                        local = dict(scope)
                        exec(compile(payload['source'], '<candidate>', 'exec'), local)
                        results.append({'output': normalize(local['solve']([row[:] for row in g]))})
                    except BaseException as exc:
                        results.append({'error': type(exc).__name__, 'detail': str(exc)[:500]})
        except BaseException as exc:
            json.dump({'error': type(exc).__name__, 'detail': str(exc)[:500], 'stdout': capture.getvalue()}, output_stream)
            return
    json.dump({'results': results, 'stdout': capture.getvalue(), 'sandbox': 'seccomp'}, output_stream)


if __name__ == '__main__':
    main()
