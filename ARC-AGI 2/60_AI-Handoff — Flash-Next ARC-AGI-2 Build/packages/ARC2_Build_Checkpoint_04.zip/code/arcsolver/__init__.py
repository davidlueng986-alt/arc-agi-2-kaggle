"""Executable-program induction for ARC; no evaluation labels enter search."""
__version__ = '0.1.0'
