from collections import Counter


def diff(actual, expected):
    shape = [len(actual), len(actual[0])]
    target_shape = [len(expected), len(expected[0])]
    mismatches = [[r, c, actual[r][c], expected[r][c]]
                  for r in range(min(len(actual), len(expected)))
                  for c in range(min(len(actual[0]), len(expected[0])))
                  if actual[r][c] != expected[r][c]]
    same = shape == target_shape
    total = len(expected) * len(expected[0])
    return {'exact': same and not mismatches, 'shape': shape, 'expected_shape': target_shape,
            'wrong_cells': len(mismatches) if same else None,
            'cell_accuracy': (total-len(mismatches))/total if same else 0,
            'first_differences_r_c_actual_expected': mismatches[:32],
            'colours': dict(Counter(c for row in actual for c in row)),
            'expected_colours': dict(Counter(c for row in expected for c in row))}


def verify(execution, train):
    if execution.get('error'):
        return {'exact': False, 'fit': 0, 'cell_accuracy': 0, 'failure': execution['error'],
                'detail': execution.get('detail', ''), 'pairs': []}
    if len(execution.get('results', [])) != len(train):
        return {'exact': False, 'fit': 0, 'cell_accuracy': 0, 'failure': 'protocol_error', 'pairs': []}
    pairs = []
    for i, (result, pair) in enumerate(zip(execution['results'], train)):
        d = ({'exact': False, 'cell_accuracy': 0, 'error': result['error'], 'detail': result.get('detail')}
             if result.get('error') else diff(result['output'], pair['output']))
        pairs.append(dict(d, pair=i))
    fit = sum(p['exact'] for p in pairs)/len(pairs)
    return {'exact': fit == 1, 'fit': fit,
            'cell_accuracy': sum(p['cell_accuracy'] for p in pairs)/len(pairs),
            'failure': None if fit == 1 else ('code_error' if any(p.get('error') for p in pairs) else 'wrong_rule'),
            'pairs': pairs}
