import json
from pathlib import Path
import time
from .data import grid


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value, separators=(',', ':')))
    tmp.replace(path)


def validate_submission(submission, tasks):
    if set(submission) != set(tasks):
        raise ValueError('submission task IDs do not match input IDs')
    for key, task in tasks.items():
        if len(submission[key]) != len(task['test']):
            raise ValueError('wrong test count: '+key)
        for pair in submission[key]:
            if set(pair) != {'attempt_1','attempt_2'}:
                raise ValueError('wrong attempt keys')
            grid(pair['attempt_1']); grid(pair['attempt_2'])
    return True


def metrics(results, labels, gpu_count=0, total_seconds=None):
    labelled = [r for r in results if r['task_id'] in labels]
    output_count = sum(len(labels[r['task_id']]) for r in labelled)
    n1 = n2 = verified_correct = verified_outputs = 0
    for r in labelled:
        truth = labels[r['task_id']]
        for i, expected in enumerate(truth):
            p = r['predictions'][i]
            n1 += p['attempt_1'] == expected
            n2 += expected in (p['attempt_1'],p['attempt_2'])
            fits = [c for c in r['archive'] if c['verification']['exact']]
            if fits:
                verified_outputs += 1
                verified_correct += any(c.get('outputs') and c['outputs'][i] == expected for c in fits)
    seconds = total_seconds if total_seconds is not None else sum(r['seconds'] for r in results)
    device_hours = seconds*gpu_count/3600 if gpu_count else None
    exact_count = sum(r['train_exact'] for r in results)
    failure_counts = {}
    for r in results:
        for f in r['failures']:
            failure_counts[f] = failure_counts.get(f,0)+1
    return {'tasks':len(results), 'labelled_test_outputs':output_count,
            'public_eval_pass_at_1': n1/output_count if output_count else None,
            'public_eval_pass_at_2': n2/output_count if output_count else None,
            'exact_train_fit_rate':exact_count/len(results) if results else None,
            'train_fit_to_test_fit':verified_correct/verified_outputs if verified_outputs else None,
            'verified_correct_outputs':verified_correct, 'verified_outputs':verified_outputs,
            'gpu_device_hours':device_hours,
            'correct_verified_outputs_per_gpu_hour':verified_correct/device_hours if device_hours else None,
            'candidates_per_task':sum(r['generated_candidates'] for r in results)/len(results) if results else 0,
            'repair_iterations':sum(r['repair_iterations'] for r in results),
            'seconds':seconds, 'failure_categories':failure_counts,
            'metric_definition':'deterministic two-attempt exact accuracy per test output; GPU-hour sums all attached device hours'}


def run_evaluation(tasks, labels, solver, outdir, budget_seconds=3600, gpu_count=0, submission_path=None):
    """Search sees only tasks. Held-out labels are consumed after selection."""
    start = time.monotonic()
    outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    submission = {k:[{'attempt_1':p['input'],'attempt_2':[[0]]} for p in t['test']] for k,t in tasks.items()}
    atomic_json(outdir/'submission.json',submission)
    if submission_path:atomic_json(submission_path,submission)
    results = []
    for index,(key,task) in enumerate(tasks.items()):
        remaining = budget_seconds-(time.monotonic()-start)
        if remaining < 1:
            break
        # Equal initial share, capped by config; saved time flows to remaining tasks.
        deadline = time.monotonic()+min(solver.config.task_seconds,remaining/max(1,len(tasks)-index))
        r = solver.solve(key,task,outdir/'traces',deadline)
        results.append(r)
        submission[key] = r['predictions']
        validate_submission(submission,tasks)
        atomic_json(outdir/'submission.json',submission)
        if submission_path:atomic_json(submission_path,submission)
        atomic_json(outdir/'metrics.json',metrics(results,labels,gpu_count,time.monotonic()-start))
        print(json.dumps({'task':key,'train_exact':r['train_exact'],'seconds':r['seconds'],
                          'candidates':r['generated_candidates']}),flush=True)
    report=metrics(results,labels,gpu_count,time.monotonic()-start)
    report['scheduled_tasks']=len(tasks)
    report['completed_tasks']=len(results)
    report['full_set_complete']=len(results)==len(tasks)
    # Include unanswered tasks in benchmark denominator. Preallocated fallbacks
    # are scored too, while completion and verified accuracy remain explicit.
    if labels:
        truth_count=sum(len(labels[k]) for k in tasks if k in labels)
        hits=[sum(p[f'attempt_{j}']==g for k in tasks if k in labels
                  for p,g in zip(submission[k],labels[k])) for j in (1,2)]
        both=sum(g in (p['attempt_1'],p['attempt_2']) for k in tasks if k in labels
                 for p,g in zip(submission[k],labels[k]))
        report['scheduled_public_eval_pass_at_1']=hits[0]/truth_count if truth_count else None
        report['scheduled_public_eval_pass_at_2']=both/truth_count if truth_count else None
    atomic_json(outdir/'metrics.json',report)
    return report
