import json
from pathlib import Path
import subprocess
import sys
import tarfile
from .runtime_layers import sha256


def model_python(inputs):
    if sys.version_info[:2]==(3,12):return sys.executable
    manifests=list(Path(inputs).rglob('provenance.json'))
    for m in manifests:
        try:p=json.loads(m.read_text())
        except ValueError:continue
        if p.get('publisher')!='astral-sh/python-build-standalone' or p.get('python')!='3.12.15':continue
        archive=m.parent/p['file']
        # Pin the official byte hash independently of the colocated manifest.
        if sha256(archive)!='5ff9f0602ce964a529ed1e8555d3abab6341926d724402ba9a15e9e877191124':
            raise RuntimeError('standalone Python checksum mismatch')
        root=Path('/tmp/arc2-python312');root.mkdir(exist_ok=True)
        with tarfile.open(archive) as z:z.extractall(root,filter='data')
        binary=root/'python/bin/python3.12'
        cp=subprocess.run([str(binary),'-I','-c','import sys;assert sys.version_info[:2]==(3,12);print(sys.version)'],capture_output=True,text=True,check=True)
        print('model interpreter: '+cp.stdout,flush=True)
        return str(binary)
    raise RuntimeError('Python3.12 required: attach completed kernel output liangwanyiudavid/arc2-runtime-builder')
