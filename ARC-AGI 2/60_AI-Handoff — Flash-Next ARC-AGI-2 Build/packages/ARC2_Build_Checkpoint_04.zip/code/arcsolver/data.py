import copy
import hashlib
import json
from pathlib import Path


def grid(value):
    if not isinstance(value, list) or not 1 <= len(value) <= 30:
        raise ValueError('grid height must be 1..30')
    if not isinstance(value[0], list) or not 1 <= len(value[0]) <= 30:
        raise ValueError('grid width must be 1..30')
    width = len(value[0])
    if any(not isinstance(row, list) or len(row) != width for row in value):
        raise ValueError('ragged grid')
    if any(type(cell) is not int or not 0 <= cell <= 9 for row in value for cell in row):
        raise ValueError('cells must be integer colours 0..9')
    return copy.deepcopy(value)


def clean_task(task):
    """Intentionally discard test output, even if source contains it."""
    if not task.get('train') or not task.get('test'):
        raise ValueError('empty task')
    return {'train': [{'input': grid(p['input']), 'output': grid(p['output'])}
                      for p in task['train']],
            'test': [{'input': grid(p['input'])} for p in task['test']]}


def load_tasks(path):
    path = Path(path)
    raw = ({p.stem: json.loads(p.read_text()) for p in sorted(path.glob('*.json'))}
           if path.is_dir() else json.loads(path.read_text()))
    if 'train' in raw and 'test' in raw:
        raw = {path.stem: raw}
    tasks, labels = {}, {}
    for key, value in sorted(raw.items()):
        tasks[key] = clean_task(value)
        if all('output' in p for p in value['test']):
            labels[key] = [grid(p['output']) for p in value['test']]
    return tasks, labels


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def fixed_subset(tasks, count=12, seed=20261024):
    """Stratify by dimensions and size without looking at test labels."""
    bins = {}
    for key, task in tasks.items():
        p = task['train'][0]
        same_shape = (len(p['input']), len(p['input'][0])) == (len(p['output']), len(p['output'][0]))
        large = max(len(x['input']) * len(x['input'][0]) for x in task['train']) > 144
        bins.setdefault((same_shape, large), []).append(key)
    for keys in bins.values():
        keys.sort(key=lambda k: digest([seed, k]))
    result = []
    while len(result) < min(count, len(tasks)):
        for b in sorted(bins):
            if bins[b] and len(result) < count:
                result.append(bins[b].pop(0))
    return result
