"""Zero-GPU counterfactual selection/filter ablations on a frozen generated pool.
This cannot establish equal-budget *generation* gains: discarded generations
still consumed compute, and repair affects subsequent model state.
"""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parents[1]))
from arcsolver.data import load_tasks
from arcsolver.search import select
from arcsolver.evaluate import metrics, atomic_json

p=argparse.ArgumentParser();p.add_argument('--traces',required=True)
p.add_argument('--tasks',required=True);p.add_argument('--labels');p.add_argument('--out',required=True)
a=p.parse_args();tasks,labels=load_tasks(a.tasks)
if a.labels:labels=json.loads(Path(a.labels).read_text())
records=[json.loads(f.read_text()) for f in sorted(Path(a.traces).glob('*/result.json'))]
policies={
    'A1_first_program':(lambda xs:xs[:1],False),
    'A2_first_root_with_repairs':(lambda xs:[c for c in xs if c['root']==0],False),
    'A3_independent_roots':(lambda xs:[c for c in xs if c['repair']==0],True),
    'A4_full_pool_duplicate_second':(lambda xs:xs,False),
    'A5_full_pool_distinct_outputs':(lambda xs:xs,True)}
report={'protocol':'fixed-generated-pool replay; NOT an equal-budget generation experiment',
        'coverage_task_ids':[r['task_id'] for r in records],'policies':{}}
for name,(keep,diversity) in policies.items():
    outputs=[]
    for r in records:
        archive=keep(r['archive'])
        rr=dict(r,archive=archive,predictions=select(archive,tasks[r['task_id']],diversity),
                train_exact=any(c['verification']['exact'] for c in archive),
                generated_candidates=len(archive),repair_iterations=sum(c['repair']>0 for c in archive))
        outputs.append(rr)
    report['policies'][name]=metrics(outputs,labels)
atomic_json(a.out,report)
print(json.dumps(report,indent=2))
