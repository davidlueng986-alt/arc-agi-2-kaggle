"""Verify every byte and path against the manifest inside a research checkpoint."""
import argparse
import hashlib
import json
from pathlib import PurePosixPath
import zipfile

p=argparse.ArgumentParser();p.add_argument('archive');a=p.parse_args()
with zipfile.ZipFile(a.archive) as z:
    names=z.namelist()
    if len(names)!=len(set(names)):raise ValueError('duplicate ZIP paths')
    for name in names:
        q=PurePosixPath(name)
        if q.is_absolute() or '..' in q.parts:raise ValueError('unsafe ZIP path')
    manifest=json.loads(z.read('MANIFEST.json'))
    if set(names)!={'MANIFEST.json',*(x['path'] for x in manifest)}:raise ValueError('manifest path mismatch')
    total=0
    for x in manifest:
        data=z.read(x['path']);total+=len(data)
        if len(data)!=x['bytes'] or hashlib.sha256(data).hexdigest()!=x['sha256']:
            raise ValueError('checksum mismatch: '+x['path'])
print(json.dumps({'status':'verified','files':len(manifest),'uncompressed_bytes':total}))
