import argparse
import hashlib
import json
from pathlib import Path
import zipfile

p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--name',required=True)
a=p.parse_args();root=Path(a.root).resolve()
items=[f for f in sorted(root.rglob('*')) if f.is_file() and
       'packages' not in f.relative_to(root).parts and '__pycache__' not in f.parts and
       f.relative_to(root).as_posix()!='MANIFEST.json']
manifest=[]
for f in items:
    h=hashlib.sha256()
    with f.open('rb') as inp:
        for part in iter(lambda:inp.read(8*1024**2),b''):h.update(part)
    manifest.append({'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':h.hexdigest()})
mf=root/'packages'/(a.name+'-MANIFEST.json');mf.parent.mkdir(exist_ok=True)
mf.write_text(json.dumps(manifest,indent=2))
archive=root/'packages'/(a.name+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in items:z.write(f,f.relative_to(root))
    z.write(mf,'MANIFEST.json')
print(archive)
