"""Guarded push. Defaults to CPU; GPU requests reserve the full timeout first."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

p=argparse.ArgumentParser();p.add_argument('--folder',required=True);p.add_argument('--seconds',type=int,required=True)
mode=p.add_mutually_exclusive_group()
mode.add_argument('--gpu',action='store_true')
mode.add_argument('--submission-snapshot',action='store_true',
                  help='Quick Save L4 metadata for official rerun; MUST NOT execute an ordinary session')
p.add_argument('--ledger',required=True)
a=p.parse_args(); folder=Path(a.folder);metadata=folder/'kernel-metadata.json'
j=json.loads(metadata.read_text());j['enable_gpu']=a.gpu or a.submission_snapshot
j['machine_shape']='NvidiaL4' if j['enable_gpu'] else 'None'
ledger=Path(a.ledger);state=json.loads(ledger.read_text())
cmd=[sys.executable,'-m','kaggle','kernels','push','-p',str(folder),'-t',str(a.seconds)]
if a.gpu:
    reserved=sum(r.get('requested_timeout_seconds',0) for r in state['runs'])
    cap=min(6900,state.get('strict_total_validation_seconds',6900))
    if reserved+a.seconds>cap or a.seconds<=0:raise SystemExit('GPU budget would exceed strict project cap')
    state['runs'].append({'id':f'G{len(state["runs"])+1:02d}','kernel':j['id'],
                          'requested_timeout_seconds':a.seconds,'status':'reserved_before_push','epoch':time.time()})
    tmp=ledger.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2));tmp.replace(ledger)
    cmd+=['--accelerator','NvidiaL4']
elif a.submission_snapshot:
    # Kaggle CLI maps this to KernelExecutionType.QUICK_SAVE. No accelerator
    # session is started; only an explicitly separate competition submission runs.
    cmd+=['--no-run']
    state.setdefault('submission_metadata_snapshots',[]).append({
        'kernel':j['id'],'ordinary_execution_requested':False,'cli_flag':'--no-run',
        'metadata_machine_shape':'NvidiaL4','epoch':time.time()})
    tmp=ledger.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2));tmp.replace(ledger)
metadata.write_text(json.dumps(j,indent=2))
result=subprocess.run(cmd)
raise SystemExit(result.returncode)
