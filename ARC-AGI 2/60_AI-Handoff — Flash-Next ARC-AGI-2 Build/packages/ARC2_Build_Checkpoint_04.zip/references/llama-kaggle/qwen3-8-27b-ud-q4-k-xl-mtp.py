import base64
import hashlib
import json
import glob
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import http.client
import http.server
import socketserver
import threading
from pathlib import Path


MODEL_FILE = "Qwen3.8-27B-UD-Q4_K_XL.gguf"
MMPROJ_FILE = "mmproj-F16.gguf"
MODEL_ALIAS = "qwen3.8-27b-ud-q4-k-xl-mtp"
LLAMA_CPP_REPOSITORY = "https://github.com/ggml-org/llama.cpp.git"
# Per-model commit, filled by Deploy-QwenKaggleMcp.ps1 (default ba360efe /
# b10375: first release with native muse-glimmer arch, llama_kv_cache_iswa
# hybrid SWA cache, DFlash --spec-type, mtmd MuseGlimmer vision). Models with a
# newer architecture (Qwen3.8/qwen35) pin their own commit + runtime Dataset
# via llama_cpp_commit / runtime_dataset_handle in kaggle\models.json.
LLAMA_CPP_COMMIT = "16d222fc5ead59d20039501a37251c9ed457a454"
SERVING_NOTEBOOK_FINGERPRINT = "qwen-serving-v3|Qwen3.8-27B-UD-Q4_K_XL.gguf|mmproj-F16.gguf|16d222fc5ead59d20039501a37251c9ed457a454"
RUNTIME_KIND = "qwen-kaggle-llama-runtime"
RUNTIME_SCHEMA_VERSION = 1
# Hard thinking mode (model entry 'thinking: true'): llama-server always enables
# the model's thinking chain for every request. Filled by Deploy; empty = no flag.
# NOTE: single-quoted placeholder â€” the injected value is a JSON string full of
# double quotes, so it must never be wrapped in Python double quotes.
CHAT_TEMPLATE_KWARGS = '{"enable_thinking":true}'
EXPECTED_RUNTIME_CUDA = "12.8"
EXPECTED_RUNTIME_ARCHITECTURES = ["75"]
EXPECTED_RUNTIME_FLAGS = {
    "BUILD_SHARED_LIBS": "ON",
    "GGML_CUDA": "ON",
    "GGML_NATIVE": "OFF",
    "LLAMA_CURL": "OFF",
    "CMAKE_BUILD_TYPE": "Release",
    "CMAKE_CUDA_ARCHITECTURES": "75",
}
REQUIRED_RUNTIME_ARTIFACTS = {
    "llama-server",
    "cloudflared",
    "libllama.so",
    "libggml.so",
    "libggml-base.so",
    "libggml-cpu.so",
    "libggml-cuda.so",
}
API_KEY = "qk_rvmr5aKxyM2U1irKpokOwGqJpafa1Bu9YNmg5gwTcrr1lIEm"
NTFY_TOPIC = "qwen-cfbabcddebe243dabf6bc08db21eae50"
CHAT_TEMPLATE_B64 = "eyUtIHNldCBpbWFnZV9jb3VudCA9IG5hbWVzcGFjZSh2YWx1ZT0wKSAlfQp7JS0gc2V0IHZpZGVvX2NvdW50ID0gbmFtZXNwYWNlKHZhbHVlPTApICV9CnslLSBtYWNybyByZW5kZXJfY29udGVudChjb250ZW50LCBkb192aXNpb25fY291bnQsIGlzX3N5c3RlbV9jb250ZW50PWZhbHNlKSAlfQogICAgeyUtIGlmIGNvbnRlbnQgaXMgc3RyaW5nICV9CiAgICAgICAge3stIGNvbnRlbnQgfX0KICAgIHslLSBlbGlmIGNvbnRlbnQgaXMgaXRlcmFibGUgYW5kIGNvbnRlbnQgaXMgbm90IG1hcHBpbmcgJX0KICAgICAgICB7JS0gZm9yIGl0ZW0gaW4gY29udGVudCAlfQogICAgICAgICAgICB7JS0gaWYgJ2ltYWdlJyBpbiBpdGVtIG9yICdpbWFnZV91cmwnIGluIGl0ZW0gb3IgaXRlbS50eXBlID09ICdpbWFnZScgJX0KICAgICAgICAgICAgICAgIHslLSBpZiBpc19zeXN0ZW1fY29udGVudCAlfQogICAgICAgICAgICAgICAgICAgIHt7LSByYWlzZV9leGNlcHRpb24oJ1N5c3RlbSBtZXNzYWdlIGNhbm5vdCBjb250YWluIGltYWdlcy4nKSB9fQogICAgICAgICAgICAgICAgeyUtIGVuZGlmICV9CiAgICAgICAgICAgICAgICB7JS0gaWYgZG9fdmlzaW9uX2NvdW50ICV9CiAgICAgICAgICAgICAgICAgICAgeyUtIHNldCBpbWFnZV9jb3VudC52YWx1ZSA9IGltYWdlX2NvdW50LnZhbHVlICsgMSAlfQogICAgICAgICAgICAgICAgeyUtIGVuZGlmICV9CiAgICAgICAgICAgICAgICB7JS0gaWYgYWRkX3Zpc2lvbl9pZCAlfQogICAgICAgICAgICAgICAgICAgIHt7LSAnUGljdHVyZSAnIH4gaW1hZ2VfY291bnQudmFsdWUgfiAnOiAnIH19CiAgICAgICAgICAgICAgICB7JS0gZW5kaWYgJX0KICAgICAgICAgICAgICAgIHt7LSAnPHx2aXNpb25fc3RhcnR8Pjx8aW1hZ2VfcGFkfD48fHZpc2lvbl9lbmR8PicgfX0KICAgICAgICAgICAgeyUtIGVsaWYgJ3ZpZGVvJyBpbiBpdGVtIG9yIGl0ZW0udHlwZSA9PSAndmlkZW8nICV9CiAgICAgICAgICAgICAgICB7JS0gaWYgaXNfc3lzdGVtX2NvbnRlbnQgJX0KICAgICAgICAgICAgICAgICAgICB7ey0gcmFpc2VfZXhjZXB0aW9uKCdTeXN0ZW0gbWVzc2FnZSBjYW5ub3QgY29udGFpbiB2aWRlb3MuJykgfX0KICAgICAgICAgICAgICAgIHslLSBlbmRpZiAlfQogICAgICAgICAgICAgICAgeyUtIGlmIGRvX3Zpc2lvbl9jb3VudCAlfQogICAgICAgICAgICAgICAgICAgIHslLSBzZXQgdmlkZW9fY291bnQudmFsdWUgPSB2aWRlb19jb3VudC52YWx1ZSArIDEgJX0KICAgICAgICAgICAgICAgIHslLSBlbmRpZiAlfQogICAgICAgICAgICAgICAgeyUtIGlmIGFkZF92aXNpb25faWQgJX0KICAgICAgICAgICAgICAgICAgICB7ey0gJ1ZpZGVvICcgfiB2aWRlb19jb3VudC52YWx1ZSB+ICc6ICcgfX0KICAgICAgICAgICAgICAgIHslLSBlbmRpZiAlfQogICAgICAgICAgICAgICAge3stICc8fHZpc2lvbl9zdGFydHw+PHx2aWRlb19wYWR8Pjx8dmlzaW9uX2VuZHw+JyB9fQogICAgICAgICAgICB7JS0gZWxpZiAndGV4dCcgaW4gaXRlbSAlfQogICAgICAgICAgICAgICAge3stIGl0ZW0udGV4dCB9fQogICAgICAgICAgICB7JS0gZWxzZSAlfQogICAgICAgICAgICAgICAge3stIHJhaXNlX2V4Y2VwdGlvbignVW5leHBlY3RlZCBpdGVtIHR5cGUgaW4gY29udGVudC4nKSB9fQogICAgICAgICAgICB7JS0gZW5kaWYgJX0KICAgICAgICB7JS0gZW5kZm9yICV9CiAgICB7JS0gZWxpZiBjb250ZW50IGlzIG5vbmUgb3IgY29udGVudCBpcyB1bmRlZmluZWQgJX0KICAgICAgICB7ey0gJycgfX0KICAgIHslLSBlbHNlICV9CiAgICAgICAge3stIHJhaXNlX2V4Y2VwdGlvbignVW5leHBlY3RlZCBjb250ZW50IHR5cGUuJykgfX0KICAgIHslLSBlbmRpZiAlfQp7JS0gZW5kbWFjcm8gJX0KeyUtIGlmIG5vdCBtZXNzYWdlcyAlfQogICAge3stIHJhaXNlX2V4Y2VwdGlvbignTm8gbWVzc2FnZXMgcHJvdmlkZWQuJykgfX0KeyUtIGVuZGlmICV9CnslLSBzZXQgc3lzbnMgPSBuYW1lc3BhY2UoY291bnQ9MCwgdGV4dD0nJykgJX0KeyUtIGZvciBtZXNzYWdlIGluIG1lc3NhZ2VzICV9CiAgICB7JS0gaWYgc3lzbnMuY291bnQgPT0gbG9vcC5pbmRleDAgYW5kIChtZXNzYWdlLnJvbGUgPT0gJ3N5c3RlbScgb3IgbWVzc2FnZS5yb2xlID09ICdkZXZlbG9wZXInKSAlfQogICAgICAgIHslLSBzZXQgc3lzX2NvbnRlbnQgPSByZW5kZXJfY29udGVudChtZXNzYWdlLmNvbnRlbnQsIGZhbHNlLCB0cnVlKXx0cmltICV9CiAgICAgICAgeyUtIGlmIHN5c19jb250ZW50ICV9CiAgICAgICAgICAgIHslLSBzZXQgc3lzbnMudGV4dCA9IHN5c25zLnRleHQgKyAoJ1xuJyBpZiBzeXNucy50ZXh0IGVsc2UgJycpICsgc3lzX2NvbnRlbnQgJX0KICAgICAgICB7JS0gZW5kaWYgJX0KICAgICAgICB7JS0gc2V0IHN5c25zLmNvdW50ID0gc3lzbnMuY291bnQgKyAxICV9CiAgICB7JS0gZW5kaWYgJX0KeyUtIGVuZGZvciAlfQp7JS0gc2V0IG51bV9zeXMgPSBzeXNucy5jb3VudCAlfQp7JS0gc2V0IG1lcmdlZF9zeXN0ZW0gPSBzeXNucy50ZXh0ICV9CnslLSBzZXQgcmVhc29uaW5nX2luc3RydWN0aW9ucyA9ICcnICV9CnslLSBzZXQgcmVzb2x2ZWRfcHJlc2VydmVfdGhpbmtpbmcgPSBmYWxzZSAlfQp7JS0gaWYgZW5hYmxlX3RoaW5raW5nIGlzIHVuZGVmaW5lZCBvciBlbmFibGVfdGhpbmtpbmcgaXMgdHJ1ZSAlfQogICAgeyUtIHNldCBfZWZmb3J0X3JhdyA9IHJlYXNvbmluZ19lZmZvcnR8ZGVmYXVsdCgnbWVkaXVtJyl8c3RyaW5nICV9CiAgICB7JS0gaWYgX2VmZm9ydF9yYXcuZW5kc3dpdGgoJytwcmVzZXJ2ZScpICV9CiAgICAgICAgeyUtIHNldCByZXNvbHZlZF9wcmVzZXJ2ZV90aGlua2luZyA9IHRydWUgJX0KICAgICAgICB7JS0gc2V0IF9lZmZvcnRfY2xlYW4gPSBfZWZmb3J0X3Jhd3xyZXBsYWNlKCcrcHJlc2VydmUnLCAnJykgJX0KICAgIHslLSBlbHNlICV9CiAgICAgICAgeyUtIHNldCBfZWZmb3J0X2NsZWFuID0gX2VmZm9ydF9yYXcgJX0KICAgIHslLSBlbmRpZiAlfQogICAgeyUtIHNldCByZXNvbHZlZF9yZWFzb25pbmdfZWZmb3J0ID0gX2VmZm9ydF9jbGVhbiAlfQogICAgeyUtIGlmIHJlc29sdmVkX3JlYXNvbmluZ19lZmZvcnQgPT0gJ2hpZ2gnICV9CiAgICAgICAgeyUtIHNldCByZXNvbHZlZF9yZWFzb25pbmdfZWZmb3J0ID0gJ3hoaWdoJyAlfQogICAgeyUtIGVuZGlmICV9CiAgICB7JS0gaWYgcmVzb2x2ZWRfcmVhc29uaW5nX2VmZm9ydCBub3QgaW4gKCd4aGlnaCcsICdtZWRpdW0nLCAnbG93JykgJX0KICAgICAgICB7JS0gc2V0IHJlc29sdmVkX3JlYXNvbmluZ19lZmZvcnQgPSAnbWVkaXVtJyAlfQogICAgeyUtIGVuZGlmICV9CiAgICB7JS0gaWYgcmVzb2x2ZWRfcmVhc29uaW5nX2VmZm9ydCA9PSAneGhpZ2gnICV9CiAgICAgICAgeyUtIHNldCByZWFzb25pbmdfaW5zdHJ1Y3Rpb25zID0gJ1JlYXNvbmluZyBlZmZvcnQgaXMgc2V0IHRvIHhoaWdoICh3aXRoIHByZXNlcnZlZCB0aGlua2luZykuIFBsZWFzZSB0aGluayBjYXJlZnVsbHkgdGhyb3VnaCB0aGUgdGFzaywgdmFsaWRhdGUga2V5IGFzc3VtcHRpb25zLCBjb25zaWRlciBwbGF1c2libGUgYWx0ZXJuYXRpdmVzLCBhbmQgcHJpb3JpdGl6ZSBjb3JyZWN0bmVzcywgY29uc2lzdGVuY3ksIGFuZCBjbGFyaXR5IGluIHRoZSBmaW5hbCBhbnN3ZXIuJyAlfQogICAgeyUtIGVsaWYgcmVzb2x2ZWRfcmVhc29uaW5nX2VmZm9ydCA9PSAnbG93JyAlfQogICAgICAgIHslLSBzZXQgcmVhc29uaW5nX2luc3RydWN0aW9ucyA9ICdSZWFzb25pbmcgZWZmb3J0IGlzIHNldCB0byBsb3cuIEtlZXAgeW91ciB0aGlua2luZyBicmllZiBhbmQgZm9jdXNlZCwgbW92aW5nIGRpcmVjdGx5IHRvIHRoZSBjb25jbHVzaW9uIHdpdGhvdXQgdW5uZWNlc3NhcnkgZWxhYm9yYXRpb24uJyAlfQogICAgeyUtIGVuZGlmICV9CnslLSBlbmRpZiAlfQp7JS0gaWYgdG9vbHMgYW5kIHRvb2xzIGlzIGl0ZXJhYmxlIGFuZCB0b29scyBpcyBub3QgbWFwcGluZyAlfQogICAge3stICc8fGltX3N0YXJ0fD5zeXN0ZW1cbicgfX0KICAgIHslLSBpZiByZWFzb25pbmdfaW5zdHJ1Y3Rpb25zICV9CiAgICAgICAge3stIHJlYXNvbmluZ19pbnN0cnVjdGlvbnMgKyAnXG5cbicgfX0KICAgIHslLSBlbmRpZiAlfQogICAge3stICIjIFRvb2xzXG5cbllvdSBoYXZlIGFjY2VzcyB0byB0aGUgZm9sbG93aW5nIGZ1bmN0aW9uczpcblxuPHRvb2xzPiIgfX0KICAgIHslLSBmb3IgdG9vbCBpbiB0b29scyAlfQogICAgICAgIHt7LSAiXG4iIH19CiAgICAgICAge3stIHRvb2wgfCB0b2pzb24gfX0KICAgIHslLSBlbmRmb3IgJX0KICAgIHt7LSAiXG48L3Rvb2xzPiIgfX0KICAgIHt7LSAnXG5cbklmIHlvdSBjaG9vc2UgdG8gY2FsbCBhIGZ1bmN0aW9uIE9OTFkgcmVwbHkgaW4gdGhlIGZvbGxvd2luZyBmb3JtYXQgd2l0aCBOTyBzdWZmaXg6XG5cbjx0b29sX2NhbGw+XG48ZnVuY3Rpb249ZXhhbXBsZV9mdW5jdGlvbl9uYW1lPlxuPHBhcmFtZXRlcj1leGFtcGxlX3BhcmFtZXRlcl8xPlxudmFsdWVfMVxuPC9wYXJhbWV0ZXI+XG48cGFyYW1ldGVyPWV4YW1wbGVfcGFyYW1ldGVyXzI+XG5UaGlzIGlzIHRoZSB2YWx1ZSBmb3IgdGhlIHNlY29uZCBwYXJhbWV0ZXJcbnRoYXQgY2FuIHNwYW5cbm11bHRpcGxlIGxpbmVzXG48L3BhcmFtZXRlcj5cbjwvZnVuY3Rpb24+XG48L3Rvb2xfY2FsbD5cblxuPElNUE9SVEFOVD5cblJlbWluZGVyOlxuLSBGdW5jdGlvbiBjYWxscyBNVVNUIGZvbGxvdyB0aGUgc3BlY2lmaWVkIGZvcm1hdDogYW4gaW5uZXIgPGZ1bmN0aW9uPS4uLj48L2Z1bmN0aW9uPiBibG9jayBtdXN0IGJlIG5lc3RlZCB3aXRoaW4gPHRvb2xfY2FsbD48L3Rvb2xfY2FsbD4gWE1MIHRhZ3Ncbi0gUmVxdWlyZWQgcGFyYW1ldGVycyBNVVNUIGJlIHNwZWNpZmllZFxuLSBZb3UgbWF5IHByb3ZpZGUgb3B0aW9uYWwgcmVhc29uaW5nIGZvciB5b3VyIGZ1bmN0aW9uIGNhbGwgaW4gbmF0dXJhbCBsYW5ndWFnZSBCRUZPUkUgdGhlIGZ1bmN0aW9uIGNhbGwsIGJ1dCBOT1QgYWZ0ZXJcbi0gSWYgdGhlcmUgaXMgbm8gZnVuY3Rpb24gY2FsbCBhdmFpbGFibGUsIGFuc3dlciB0aGUgcXVlc3Rpb24gbGlrZSBub3JtYWwgd2l0aCB5b3VyIGN1cnJlbnQga25vd2xlZGdlIGFuZCBkbyBub3QgdGVsbCB0aGUgdXNlciBhYm91dCBmdW5jdGlvbiBjYWxsc1xuPC9JTVBPUlRBTlQ+JyB9fQogICAgeyUtIGlmIG1lcmdlZF9zeXN0ZW0gJX0KICAgICAgICB7ey0gJ1xuXG4nICsgbWVyZ2VkX3N5c3RlbSB9fQogICAgeyUtIGVuZGlmICV9CiAgICB7ey0gJzx8aW1fZW5kfD5cbicgfX0KeyUtIGVsc2UgJX0KICAgIHslLSBpZiBtZXJnZWRfc3lzdGVtICV9CiAgICAgICAge3stICc8fGltX3N0YXJ0fD5zeXN0ZW1cbicgKyAocmVhc29uaW5nX2luc3RydWN0aW9ucyArICdcblxuJyBpZiByZWFzb25pbmdfaW5zdHJ1Y3Rpb25zIGVsc2UgJycpICArIG1lcmdlZF9zeXN0ZW0gKyAnPHxpbV9lbmR8PlxuJyB9fQogICAgeyUtIGVsaWYgcmVhc29uaW5nX2luc3RydWN0aW9ucyAlfQogICAgICAgIHt7LSAnPHxpbV9zdGFydHw+c3lzdGVtXG4nICsgcmVhc29uaW5nX2luc3RydWN0aW9ucyArICc8fGltX2VuZHw+XG4nIH19CiAgICB7JS0gZW5kaWYgJX0KeyUtIGVuZGlmICV9CnslLSBzZXQgbnMgPSBuYW1lc3BhY2UobXVsdGlfc3RlcF90b29sPXRydWUsIGxhc3RfcXVlcnlfaW5kZXg9bWVzc2FnZXN8bGVuZ3RoIC0gMSkgJX0KeyUtIGZvciBtZXNzYWdlIGluIG1lc3NhZ2VzWzo6LTFdICV9CiAgICB7JS0gc2V0IGluZGV4ID0gKG1lc3NhZ2VzfGxlbmd0aCAtIDEpIC0gbG9vcC5pbmRleDAgJX0KICAgIHslLSBpZiBucy5tdWx0aV9zdGVwX3Rvb2wgYW5kIG1lc3NhZ2Uucm9sZSA9PSAidXNlciIgJX0KICAgICAgICB7JS0gc2V0IGNvbnRlbnQgPSByZW5kZXJfY29udGVudChtZXNzYWdlLmNvbnRlbnQsIGZhbHNlKXx0cmltICV9CiAgICAgICAgeyUtIGlmIG5vdChjb250ZW50LnN0YXJ0c3dpdGgoJzx0b29sX3Jlc3BvbnNlPicpIGFuZCBjb250ZW50LmVuZHN3aXRoKCc8L3Rvb2xfcmVzcG9uc2U+JykpICV9CiAgICAgICAgICAgIHslLSBzZXQgbnMubXVsdGlfc3RlcF90b29sID0gZmFsc2UgJX0KICAgICAgICAgICAgeyUtIHNldCBucy5sYXN0X3F1ZXJ5X2luZGV4ID0gaW5kZXggJX0KICAgICAgICB7JS0gZW5kaWYgJX0KICAgIHslLSBlbmRpZiAlfQp7JS0gZW5kZm9yICV9CnslLSBmb3IgbWVzc2FnZSBpbiBtZXNzYWdlcyAlfQogICAgeyUtIGlmIGxvb3AuaW5kZXgwID49IG51bV9zeXMgJX0KICAgIHslLSBzZXQgY29udGVudCA9IHJlbmRlcl9jb250ZW50KG1lc3NhZ2UuY29udGVudCwgdHJ1ZSl8dHJpbSAlfQogICAgeyUtIGlmIG1lc3NhZ2Uucm9sZSA9PSAic3lzdGVtIiBvciBtZXNzYWdlLnJvbGUgPT0gImRldmVsb3BlciIgJX0KICAgICAgICB7ey0gcmFpc2VfZXhjZXB0aW9uKCdTeXN0ZW0gbWVzc2FnZSBtdXN0IGJlIGF0IHRoZSBiZWdpbm5pbmcuJykgfX0KICAgIHslLSBlbGlmIG1lc3NhZ2Uucm9sZSA9PSAidXNlciIgJX0KICAgICAgICB7ey0gJzx8aW1fc3RhcnR8PicgKyBtZXNzYWdlLnJvbGUgKyAnXG4nICsgY29udGVudCArICc8fGltX2VuZHw+JyArICdcbicgfX0KICAgIHslLSBlbGlmIG1lc3NhZ2Uucm9sZSA9PSAiYXNzaXN0YW50IiAlfQogICAgICAgIHslLSBzZXQgcmVhc29uaW5nX2NvbnRlbnQgPSAnJyAlfQogICAgICAgIHslLSBpZiBtZXNzYWdlLnJlYXNvbmluZ19jb250ZW50IGlzIHN0cmluZyAlfQogICAgICAgICAgICB7JS0gc2V0IHJlYXNvbmluZ19jb250ZW50ID0gbWVzc2FnZS5yZWFzb25pbmdfY29udGVudCAlfQogICAgICAgIHslLSBlbmRpZiAlfQogICAgICAgIHslLSBzZXQgcmVhc29uaW5nX2NvbnRlbnQgPSByZWFzb25pbmdfY29udGVudHx0cmltICV9CiAgICAgICAgeyUtIGlmIHJlc29sdmVkX3ByZXNlcnZlX3RoaW5raW5nIG9yIGxvb3AuaW5kZXgwID4gbnMubGFzdF9xdWVyeV9pbmRleCAlfQogICAgICAgICAgICB7ey0gJzx8aW1fc3RhcnR8PicgKyBtZXNzYWdlLnJvbGUgKyAnXG48dGhpbms+XG4nICsgcmVhc29uaW5nX2NvbnRlbnQgKyAnXG48L3RoaW5rPlxuXG4nICsgY29udGVudCB9fQogICAgICAgIHslLSBlbHNlICV9CiAgICAgICAgICAgIHt7LSAnPHxpbV9zdGFydHw+JyArIG1lc3NhZ2Uucm9sZSArICdcbicgKyBjb250ZW50IH19CiAgICAgICAgeyUtIGVuZGlmICV9CiAgICAgICAgeyUtIGlmIG1lc3NhZ2UudG9vbF9jYWxscyBhbmQgbWVzc2FnZS50b29sX2NhbGxzIGlzIGl0ZXJhYmxlIGFuZCBtZXNzYWdlLnRvb2xfY2FsbHMgaXMgbm90IG1hcHBpbmcgJX0KICAgICAgICAgICAgeyUtIGZvciB0b29sX2NhbGwgaW4gbWVzc2FnZS50b29sX2NhbGxzICV9CiAgICAgICAgICAgICAgICB7JS0gaWYgdG9vbF9jYWxsLmZ1bmN0aW9uIGlzIGRlZmluZWQgJX0KICAgICAgICAgICAgICAgICAgICB7JS0gc2V0IHRvb2xfY2FsbCA9IHRvb2xfY2FsbC5mdW5jdGlvbiAlfQogICAgICAgICAgICAgICAgeyUtIGVuZGlmICV9CiAgICAgICAgICAgICAgICB7JS0gaWYgdG9vbF9jYWxsLm5hbWUgaXMgbm90IGRlZmluZWQgb3IgdG9vbF9jYWxsLm5hbWUgaXMgbm9uZSAlfQogICAgICAgICAgICAgICAgICAgIHt7LSByYWlzZV9leGNlcHRpb24oJ1Rvb2wgY2FsbCBpcyBtaXNzaW5nIGEgZnVuY3Rpb24gbmFtZS4nKSB9fQogICAgICAgICAgICAgICAgeyUtIGVuZGlmICV9CiAgICAgICAgICAgICAgICB7JS0gaWYgbG9vcC5maXJzdCAlfQogICAgICAgICAgICAgICAgICAgIHslLSBpZiBjb250ZW50fHRyaW0gJX0KICAgICAgICAgICAgICAgICAgICAgICAge3stICdcblxuPHRvb2xfY2FsbD5cbjxmdW5jdGlvbj0nICsgdG9vbF9jYWxsLm5hbWUgKyAnPlxuJyB9fQogICAgICAgICAgICAgICAgICAgIHslLSBlbHNlICV9CiAgICAgICAgICAgICAgICAgICAgICAgIHt7LSAnPHRvb2xfY2FsbD5cbjxmdW5jdGlvbj0nICsgdG9vbF9jYWxsLm5hbWUgKyAnPlxuJyB9fQogICAgICAgICAgICAgICAgICAgIHslLSBlbmRpZiAlfQogICAgICAgICAgICAgICAgeyUtIGVsc2UgJX0KICAgICAgICAgICAgICAgICAgICB7ey0gJ1xuPHRvb2xfY2FsbD5cbjxmdW5jdGlvbj0nICsgdG9vbF9jYWxsLm5hbWUgKyAnPlxuJyB9fQogICAgICAgICAgICAgICAgeyUtIGVuZGlmICV9CiAgICAgICAgICAgICAgICB7JS0gaWYgdG9vbF9jYWxsLmFyZ3VtZW50cyBpcyBtYXBwaW5nICV9CiAgICAgICAgICAgICAgICAgICAgeyUtIGZvciBhcmdzX25hbWUsIGFyZ3NfdmFsdWUgaW4gdG9vbF9jYWxsLmFyZ3VtZW50c3xpdGVtcyAlfQogICAgICAgICAgICAgICAgICAgICAgICB7ey0gJzxwYXJhbWV0ZXI9JyArIGFyZ3NfbmFtZSArICc+XG4nIH19CiAgICAgICAgICAgICAgICAgICAgICAgIHslLSBzZXQgYXJnc192YWx1ZSA9IGFyZ3NfdmFsdWUgfCBzdHJpbmcgaWYgYXJnc192YWx1ZSBpcyBzdHJpbmcgZWxzZSBhcmdzX3ZhbHVlIHwgdG9qc29uIHwgc2FmZSAlfQogICAgICAgICAgICAgICAgICAgICAgICB7ey0gYXJnc192YWx1ZSB9fQogICAgICAgICAgICAgICAgICAgICAgICB7ey0gJ1xuPC9wYXJhbWV0ZXI+XG4nIH19CiAgICAgICAgICAgICAgICAgICAgeyUtIGVuZGZvciAlfQogICAgICAgICAgICAgICAgeyUtIGVsaWYgdG9vbF9jYWxsLmFyZ3VtZW50cyBpcyBzdHJpbmcgJX0KICAgICAgICAgICAgICAgICAgICB7JS0gaWYgdG9vbF9jYWxsLmFyZ3VtZW50c3x0cmltICV9CiAgICAgICAgICAgICAgICAgICAgICAgIHt7LSByYWlzZV9leGNlcHRpb24oJ1Rvb2wgY2FsbCBhcmd1bWVudHMgZm9yIGZ1bmN0aW9uICInICsgKHRvb2xfY2FsbC5uYW1lIHwgc3RyaW5nKSArICciIHdlcmUgcGFzc2VkIGFzIGEgSlNPTiBzdHJpbmcuIFBhcnNlIHRoZW0gaW50byBhbiBvYmplY3QgYmVmb3JlIGNhbGxpbmcgYXBwbHlfY2hhdF90ZW1wbGF0ZS4nKSB9fQogICAgICAgICAgICAgICAgICAgIHslLSBlbmRpZiAlfQogICAgICAgICAgICAgICAgeyUtIGVsaWYgdG9vbF9jYWxsLmFyZ3VtZW50cyBpcyBkZWZpbmVkIGFuZCB0b29sX2NhbGwuYXJndW1lbnRzIGlzIG5vdCBub25lICV9CiAgICAgICAgICAgICAgICAgICAge3stIHJhaXNlX2V4Y2VwdGlvbignVG9vbCBjYWxsIGFyZ3VtZW50cyBmb3IgZnVuY3Rpb24gIicgKyAodG9vbF9jYWxsLm5hbWUgfCBzdHJpbmcpICsgJyIgbXVzdCBiZSBhbiBvYmplY3QvbWFwcGluZyBvciBhIEpTT04gc3RyaW5nLicpIH19CiAgICAgICAgICAgICAgICB7JS0gZW5kaWYgJX0KICAgICAgICAgICAgICAgIHt7LSAnPC9mdW5jdGlvbj5cbjwvdG9vbF9jYWxsPicgfX0KICAgICAgICAgICAgeyUtIGVuZGZvciAlfQogICAgICAgIHslLSBlbmRpZiAlfQogICAgICAgIHt7LSAnPHxpbV9lbmR8PlxuJyB9fQogICAgeyUtIGVsaWYgbWVzc2FnZS5yb2xlID09ICJ0b29sIiAlfQogICAgICAgIHslLSBpZiBsb29wLnByZXZpdGVtIGFuZCBsb29wLnByZXZpdGVtLnJvbGUgIT0gInRvb2wiICV9CiAgICAgICAgICAgIHt7LSAnPHxpbV9zdGFydHw+dXNlcicgfX0KICAgICAgICB7JS0gZW5kaWYgJX0KICAgICAgICB7ey0gJ1xuPHRvb2xfcmVzcG9uc2U+XG4nIH19CiAgICAgICAge3stIGNvbnRlbnQgfX0KICAgICAgICB7ey0gJ1xuPC90b29sX3Jlc3BvbnNlPicgfX0KICAgICAgICB7JS0gaWYgbm90IGxvb3AubGFzdCBhbmQgbG9vcC5uZXh0aXRlbS5yb2xlICE9ICJ0b29sIiAlfQogICAgICAgICAgICB7ey0gJzx8aW1fZW5kfD5cbicgfX0KICAgICAgICB7JS0gZWxpZiBsb29wLmxhc3QgJX0KICAgICAgICAgICAge3stICc8fGltX2VuZHw+XG4nIH19CiAgICAgICAgeyUtIGVuZGlmICV9CiAgICB7JS0gZWxzZSAlfQogICAgICAgIHt7LSByYWlzZV9leGNlcHRpb24oJ1VuZXhwZWN0ZWQgbWVzc2FnZSByb2xlLicpIH19CiAgICB7JS0gZW5kaWYgJX0KICAgIHslLSBlbmRpZiAlfQp7JS0gZW5kZm9yICV9CnslLSBpZiBhZGRfZ2VuZXJhdGlvbl9wcm9tcHQgJX0KICAgIHt7LSAnPHxpbV9zdGFydHw+YXNzaXN0YW50XG4nIH19CiAgICB7JS0gaWYgZW5hYmxlX3RoaW5raW5nIGlzIGRlZmluZWQgYW5kIGVuYWJsZV90aGlua2luZyBpcyBmYWxzZSAlfQogICAgICAgIHt7LSAnPHRoaW5rPlxuXG48L3RoaW5rPlxuXG4nIH19CiAgICB7JS0gZWxzZSAlfQogICAgICAgIHt7LSAnPHRoaW5rPlxuJyB9fQogICAgeyUtIGVuZGlmICV9CnslLSBlbmRpZiAlfQp7Iy0gVW5zbG90aCBmaXhlcyAtIGRldmVsb3BlciByb2xlLCBtZXJnZWQgc3lzdGVtIG1lc3NhZ2VzLCB0b29sIGNhbGxpbmcgI30="
# Per-model llama-server tuning, filled by Deploy-QwenKaggleMcp.ps1 from
# kaggle\models.json (empty = keep current defaults: q8_0 K/V cache, equal
# tensor split, llama's default batch/ubatch, no explicit fit flags, mmproj on
# GPU, ChatML template file).
KV_CACHE_K = "q4_0"
KV_CACHE_V = "q4_0"
TENSOR_SPLIT = "48,52"
SPLIT_MODE = "layer"
BATCH_SIZE = "2048"
UBATCH_SIZE = "512"
FIT_TARGET = ""
FIT_MODE = "off"
FLASH_ATTN = "on"
MMPROJ_OFFLOAD = "1"
PARALLEL = "1"
# '1' = write CHAT_TEMPLATE_B64 to a file and pass --chat-template-file;
# '0' = --jinja with the GGUF-embedded template (Muse Glimmer ships "Onyx ATEM").
USE_CHAT_TEMPLATE = "1"
# Optional speculative decoding: draft_file (e.g. dflash-kquant.gguf, mounted
# with the model Dataset) + draft length in tokens (DFlash block size = 16).
DRAFT_FILE = "Qwen3.8-27B-MTP-ONLY-Q4_K_M.gguf"
SPEC_DRAFT_N_MAX = "2"
# Draft KV cache quant types (empty = llama default f16). DFlash draft KV is
# 5 layers x 8 KV heads x 128 dim x ctx; f16 @131k = 2.68 GiB, q8_0/q5_0 = 1.17.
SPEC_DRAFT_CACHE_K = ""
SPEC_DRAFT_CACHE_V = ""
# Draft confidence gate: truncate the drafted block at the first position whose
# draft probability is below this value (0 = verify the full block). Raises
# effective acceptance on low-predictability workloads by verifying fewer tokens.
SPEC_DRAFT_P_MIN = ""
# Minimum useful draft length: blocks truncated below this are discarded and
# the round falls back to a normal single-token decode (avoids paying the
# verify-batch cost for drafts too short to amortize it).
SPEC_DRAFT_N_MIN = ""
# Speculative decoding type override (empty = draft-dflash when a draft file is
# present, else none). Examples: 'ngram-simple', 'ngram-cache', 'draft-dflash'.
SPEC_TYPE = "draft-mtp"
# Artifact download fallback (filled by Deploy; empty = disabled). Kaggle
# dataset mounts are unreliable for freshly-created datasets and have outright
# outages (measured 15/08/2026: every new session mounted NOTHING while older
# running sessions kept their mounts). When any model artifact is missing from
# /kaggle/input the kernel downloads it itself: tier 1 kagglehub dataset
# download (Kaggle-internal storage), tier 2 direct HF streaming with resume.
MODEL_DATASET_HANDLE = "iyppmx/qwen38-27b-q4kxl-mtp-src-t4"
# NOTE: single-quoted placeholder â€” the injected value is a JSON object full of
# double quotes (filename -> HF resolve URL), never wrap it in Python doubles.
HF_DOWNLOAD_URLS = '{"Qwen3.8-27B-UD-Q4_K_XL.gguf":"https://huggingface.co/unsloth/Qwen3.8-27B-GGUF/resolve/main/Qwen3.8-27B-UD-Q4_K_XL.gguf","mmproj-F16.gguf":"https://huggingface.co/unsloth/Qwen3.8-27B-GGUF/resolve/main/mmproj-F16.gguf","Qwen3.8-27B-MTP-ONLY-Q4_K_M.gguf":"https://huggingface.co/a4lg/Qwen3.8-27B-MTP-ONLY-GGUF/resolve/main/Qwen3.8-27B-MTP-ONLY-Q4_K_M.gguf"}'
DOWNLOADED_ARTIFACTS = {}
WORK = Path("/kaggle/working")
LLAMA_DIR = WORK / "llama.cpp"
RUNTIME_DIR = WORK / "qwen-kaggle-runtime"
ARTIFACT_CACHE_DIR = WORK / "model-artifacts"
SERVER_LOG = WORK / "llama-server.log"
CLOUDFLARED_LOG = WORK / "cloudflared.log"
CHAT_TEMPLATE_PATH = WORK / "qwen-tool-chatml.jinja"


def run(command, **kwargs):
    print("+", " ".join(map(str, command)), flush=True)
    return subprocess.run(command, check=True, **kwargs)


def publish(phase, **fields):
    payload = {"phase": phase, **fields}
    body = json.dumps(
        {
            "topic": NTFY_TOPIC,
            "title": "qwen-kaggle",
            "message": json.dumps(payload),
        }
    ).encode()
    request = urllib.request.Request(
        "https://ntfy.sh",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            response.read()
    except Exception as exc:
        print(f"ntfy publish failed ({phase}): {exc}", flush=True)


def gpu_count():
    output = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"], text=True
    )
    names = [line.strip() for line in output.splitlines() if line.strip()]
    print(f"GPUs ({len(names)}): {names}", flush=True)
    return len(names)


def cuda_toolkit_version():
    try:
        output = subprocess.check_output(["nvcc", "--version"], text=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        return None
    match = re.search(r"release\s+(\d+\.\d+)", output)
    return match.group(1) if match else None


def gpu_architectures():
    output = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=compute_cap", "--format=csv,noheader"],
        text=True,
    )
    return sorted(
        {line.strip().replace(".", "") for line in output.splitlines() if line.strip()}
    )


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def runtime_environment(library_dir):
    env = os.environ.copy()
    env["LD_LIBRARY_PATH"] = os.pathsep.join(
        part
        for part in [str(library_dir), env.get("LD_LIBRARY_PATH", "")]
        if part
    )
    return env


def validate_runtime_manifest(manifest_path, toolkit, architectures):
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != RUNTIME_SCHEMA_VERSION:
        raise RuntimeError("unsupported manifest schema")
    if manifest.get("kind") != RUNTIME_KIND:
        raise RuntimeError("wrong runtime kind")

    source = manifest.get("source", {})
    if source.get("llama_cpp_commit") != LLAMA_CPP_COMMIT:
        raise RuntimeError("llama.cpp commit mismatch")

    target = manifest.get("target", {})
    if target.get("platform") != "linux" or target.get("machine") != platform.machine():
        raise RuntimeError("platform mismatch")
    if toolkit != EXPECTED_RUNTIME_CUDA or target.get("cuda_toolkit") != toolkit:
        raise RuntimeError(
            f"CUDA toolkit mismatch (runtime={target.get('cuda_toolkit')}, host={toolkit})"
        )
    if architectures != EXPECTED_RUNTIME_ARCHITECTURES:
        raise RuntimeError(f"host GPU architecture is not SM75: {architectures}")
    if target.get("cuda_architectures") != architectures:
        raise RuntimeError("GPU architecture mismatch")

    build = manifest.get("build", {})
    if build.get("target") != "llama-server":
        raise RuntimeError("build target mismatch")
    if build.get("flags") != EXPECTED_RUNTIME_FLAGS:
        raise RuntimeError("CMake build flags mismatch")

    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, list) or not artifacts:
        raise RuntimeError("artifact list is empty")
    names = {item.get("path") for item in artifacts if isinstance(item, dict)}
    missing = sorted(REQUIRED_RUNTIME_ARTIFACTS.difference(names))
    if missing:
        raise RuntimeError(f"required artifacts are missing from manifest: {missing}")

    source_dir = manifest_path.parent.resolve()
    verified = []
    for item in artifacts:
        if not isinstance(item, dict):
            raise RuntimeError("invalid artifact entry")
        relative = item.get("path")
        expected_digest = item.get("sha256")
        expected_size = item.get("size_bytes")
        if not isinstance(relative, str) or Path(relative).name != relative:
            raise RuntimeError(f"unsafe artifact path: {relative!r}")
        source_path = (source_dir / relative).resolve()
        if source_path.parent != source_dir or not source_path.is_file():
            raise RuntimeError(f"artifact is missing: {relative}")
        if source_path.stat().st_size != expected_size:
            raise RuntimeError(f"artifact size mismatch: {relative}")
        actual_digest = sha256_file(source_path)
        if actual_digest != expected_digest:
            raise RuntimeError(f"artifact checksum mismatch: {relative}")
        verified.append((item, source_path))

    if RUNTIME_DIR.exists():
        shutil.rmtree(RUNTIME_DIR)
    RUNTIME_DIR.mkdir(parents=True)
    for item, source_path in verified:
        destination = RUNTIME_DIR / source_path.name
        shutil.copy2(source_path, destination)
        destination.chmod(0o755 if item.get("executable") else 0o644)

    server = RUNTIME_DIR / "llama-server"
    cloudflared = RUNTIME_DIR / "cloudflared"
    env = runtime_environment(RUNTIME_DIR)
    dependencies = subprocess.check_output(["ldd", str(server)], text=True, env=env)
    if "not found" in dependencies:
        raise RuntimeError(f"cached llama-server has unresolved libraries:\n{dependencies}")
    subprocess.check_output(
        [str(server), "--version"], text=True, stderr=subprocess.STDOUT, env=env
    )
    subprocess.check_output(
        [str(cloudflared), "--version"], text=True, stderr=subprocess.STDOUT
    )
    return server, cloudflared, RUNTIME_DIR, manifest


def find_cached_runtime():
    if platform.system().lower() != "linux" or platform.machine() != "x86_64":
        raise RuntimeError(
            "Serving runtime requires Linux x86_64, got "
            f"{platform.system()} {platform.machine()}"
        )
    toolkit = cuda_toolkit_version()
    architectures = gpu_architectures()
    if toolkit != EXPECTED_RUNTIME_CUDA:
        raise RuntimeError(
            f"Serving runtime requires CUDA {EXPECTED_RUNTIME_CUDA}, got {toolkit}"
        )
    if architectures != EXPECTED_RUNTIME_ARCHITECTURES:
        raise RuntimeError(
            f"Serving runtime requires SM75/T4, got architectures {architectures}"
        )
    manifests = sorted(Path("/kaggle/input").rglob("runtime-manifest.json"))
    if not manifests:
        print("Runtime Dataset is not mounted; falling back to a local build", flush=True)
        return None
    for manifest_path in manifests:
        try:
            runtime = validate_runtime_manifest(manifest_path, toolkit, architectures)
            manifest = runtime[3]
            print(
                "Compatible runtime cache: "
                f"{manifest_path} (llama.cpp {manifest['source']['llama_cpp_commit'][:7]})",
                flush=True,
            )
            return runtime
        except Exception as exc:
            print(f"Ignoring incompatible runtime cache {manifest_path}: {exc}", flush=True)
    print("No compatible runtime cache passed validation; building locally", flush=True)
    return None


def find_cuda_driver():
    """Find the host driver library even when Kaggle omits it from ldconfig."""
    candidates = []
    try:
        ldconfig = subprocess.check_output(
            ["ldconfig", "-p"], text=True, stderr=subprocess.DEVNULL
        )
        candidates.extend(
            re.findall(r"libcuda\.so(?:\.\d+)*[^=]*=>\s*(\S+)", ldconfig)
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        pass

    patterns = [
        "/usr/lib64-nvidia/libcuda.so*",
        "/usr/local/nvidia/lib64/libcuda.so*",
        "/usr/lib/x86_64-linux-gnu/libcuda.so*",
        "/usr/lib/x86_64-linux-gnu/nvidia/current/libcuda.so*",
        "/usr/local/cuda/compat/libcuda.so*",
        "/usr/local/cuda/targets/x86_64-linux/lib/libcuda.so*",
        "/usr/local/cuda/targets/x86_64-linux/lib/stubs/libcuda.so*",
    ]
    for pattern in patterns:
        candidates.extend(glob.glob(pattern))

    unique = []
    for candidate in candidates:
        if candidate not in unique and Path(candidate).exists():
            unique.append(candidate)
    print(f"CUDA driver candidates: {unique}", flush=True)
    if not unique:
        return None

    # Prefer the mounted NVIDIA host driver. The toolkit stub is only a fallback.
    unique.sort(key=lambda path: ("/stubs/" in path, not path.endswith(".so.1")))
    return unique[0]


def build_llama_cpp():
    if LLAMA_DIR.exists():
        shutil.rmtree(LLAMA_DIR)
    run(
        [
            "git",
            "clone",
            "--filter=blob:none",
            "--no-checkout",
            LLAMA_CPP_REPOSITORY,
            str(LLAMA_DIR),
        ]
    )
    run(
        [
            "git",
            "-C",
            str(LLAMA_DIR),
            "checkout",
            "--detach",
            LLAMA_CPP_COMMIT,
        ]
    )
    env = os.environ.copy()
    env["CMAKE_BUILD_PARALLEL_LEVEL"] = "2"
    capabilities = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=compute_cap", "--format=csv,noheader"],
        text=True,
    )
    architectures = sorted(
        {line.strip().replace(".", "") for line in capabilities.splitlines() if line.strip()}
    )
    cmake_command = [
        "cmake",
        "-S",
        str(LLAMA_DIR),
        "-B",
        str(LLAMA_DIR / "build"),
    ]
    for name, value in EXPECTED_RUNTIME_FLAGS.items():
        cmake_command.append(f"-D{name}={value}")
    driver_path = find_cuda_driver()
    if driver_path:
        driver_dir = str(Path(driver_path).parent)
        existing_library_path = env.get("CMAKE_LIBRARY_PATH", "")
        env["CMAKE_LIBRARY_PATH"] = os.pathsep.join(
            part for part in [driver_dir, existing_library_path] if part
        )
        cmake_command.append(f"-DCMAKE_LIBRARY_PATH={driver_dir}")
        print(f"CUDA driver library: {driver_path}", flush=True)
    print(f"CUDA architectures: {architectures}", flush=True)
    run(cmake_command, env=env)
    run(
        [
            "cmake",
            "--build",
            str(LLAMA_DIR / "build"),
            "--config",
            "Release",
            "--target",
            "llama-server",
            "-j",
            "2",
        ],
        env=env,
    )
    commit = subprocess.check_output(
        ["git", "-C", str(LLAMA_DIR), "rev-parse", "HEAD"], text=True
    ).strip()
    if commit != LLAMA_CPP_COMMIT:
        raise RuntimeError(
            f"llama.cpp checkout mismatch: expected {LLAMA_CPP_COMMIT}, got {commit}"
        )
    print(f"llama.cpp commit: {commit}", flush=True)
    return LLAMA_DIR / "build" / "bin" / "llama-server", LLAMA_DIR / "build" / "bin"


def _hf_urls():
    if not HF_DOWNLOAD_URLS.strip():
        return {}
    try:
        return json.loads(HF_DOWNLOAD_URLS)
    except ValueError:
        return {}


def _hf_stream_download(filename, destination):
    url = _hf_urls().get(filename)
    if not url:
        raise RuntimeError(f"No HF URL configured for {filename}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.with_name(destination.name + ".part")
    for attempt in range(1, 7):
        offset = tmp.stat().st_size if tmp.exists() else 0
        headers = {"Range": f"bytes={offset}-"} if offset else {}
        print(f"HF download {filename} attempt {attempt} from byte {offset}", flush=True)
        request = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=600) as source:
                resumable = offset > 0 and source.status == 206
                with tmp.open("ab" if resumable else "wb") as out:
                    while True:
                        chunk = source.read(8 * 1024 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)
            tmp.rename(destination)
            print(f"HF download complete: {filename} ({destination.stat().st_size} bytes)", flush=True)
            return destination
        except Exception as exc:
            print(f"HF download error ({filename}): {exc}", flush=True)
    raise RuntimeError(f"HF download failed for {filename}")


def ensure_model_artifacts(required):
    """No-op when the Kaggle dataset mounts delivered everything. Otherwise
    download the missing artifacts: tier 1 kagglehub dataset download (fast
    Kaggle-internal storage), tier 2 per-file HF streaming with resume."""
    missing = [
        name
        for name in required
        if name and not list(Path("/kaggle/input").rglob(name))
    ]
    if not missing:
        return
    print(f"Dataset mount missing artifacts: {missing}; downloading.", flush=True)
    publish("downloading_artifacts", missing=missing)
    if MODEL_DATASET_HANDLE:
        try:
            import kagglehub

            local_dir = Path(kagglehub.dataset_download(MODEL_DATASET_HANDLE))
            for name in missing[:]:
                candidate = local_dir / name
                if candidate.is_file():
                    DOWNLOADED_ARTIFACTS[name] = candidate
                    missing.remove(name)
                    print(f"kagglehub artifact ready: {candidate}", flush=True)
        except Exception as exc:
            print(f"kagglehub dataset_download failed: {exc}", flush=True)
    for name in missing:
        DOWNLOADED_ARTIFACTS[name] = _hf_stream_download(
            name, ARTIFACT_CACHE_DIR / name
        )


def find_model_artifacts():
    model_candidates = [DOWNLOADED_ARTIFACTS[MODEL_FILE]] if MODEL_FILE in DOWNLOADED_ARTIFACTS else list(Path("/kaggle/input").rglob(MODEL_FILE))
    mmproj_candidates = [DOWNLOADED_ARTIFACTS[MMPROJ_FILE]] if MMPROJ_FILE in DOWNLOADED_ARTIFACTS else list(Path("/kaggle/input").rglob(MMPROJ_FILE))
    if not model_candidates:
        raise FileNotFoundError(
            f"{MODEL_FILE} is missing from mounted Kaggle Dataset inputs"
        )
    if not mmproj_candidates:
        raise FileNotFoundError(
            f"{MMPROJ_FILE} is missing from mounted Kaggle Dataset inputs"
        )
    model_path = model_candidates[0]
    mmproj_path = mmproj_candidates[0]
    model_size_gib = model_path.stat().st_size / (1024**3)
    mmproj_size_gib = mmproj_path.stat().st_size / (1024**3)
    print(
        f"Mounted model ready: {model_path} ({model_size_gib:.2f} GiB)", flush=True
    )
    print(
        f"Mounted vision projector ready: {mmproj_path} ({mmproj_size_gib:.2f} GiB)",
        flush=True,
    )
    return model_path, mmproj_path


def write_chat_template():
    CHAT_TEMPLATE_PATH.write_bytes(base64.b64decode(CHAT_TEMPLATE_B64))
    print(f"Tool-call chat template: {CHAT_TEMPLATE_PATH}", flush=True)
    return CHAT_TEMPLATE_PATH


def wait_for_health(process, timeout_seconds=1200):
    deadline = time.time() + timeout_seconds
    request = urllib.request.Request(
        "http://127.0.0.1:8080/health",
        headers={"Authorization": f"Bearer {API_KEY}"},
    )
    while time.time() < deadline:
        if process.poll() is not None:
            return False
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                if response.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(5)
    return False


def find_artifact(filename):
    if not filename:
        return None
    if filename in DOWNLOADED_ARTIFACTS:
        return DOWNLOADED_ARTIFACTS[filename]
    candidates = list(Path("/kaggle/input").rglob(filename))
    if not candidates:
        raise FileNotFoundError(f"{filename} is missing from mounted Kaggle Dataset inputs")
    return candidates[0]


def start_server(model_path, mmproj_path, count, server, library_dir):
    if USE_CHAT_TEMPLATE == "1":
        chat_template_path = write_chat_template()
    else:
        chat_template_path = None
    # Muse Glimmer on SM75/T4: flash-attention's per-token KV scan over the
    # full 131k-cell cache is the measured prefill bottleneck (O(n^2)); the
    # classic CUDA attention path is linear and faster here. Per-model switch.
    flash_attn_flag = "off" if FLASH_ATTN == "off" else "on"
    # Fallback ladder: per-model --ctx-size first, then lower it step by step.
    # 131k + hybrid SWA KV costs under 1 GiB, so the upper rung is the goal;
    # lower rungs only cover pathological VRAM pressure from buffers.
    contexts = [174080, 65536, 32768]
    draft_model_path = find_artifact(DRAFT_FILE) if DRAFT_FILE else None
    for context in contexts:
        command = [
            str(server),
            "--model",
            str(model_path),
            "--mmproj",
            str(mmproj_path),
            "--alias",
            MODEL_ALIAS,
            "--host",
            "127.0.0.1",
            "--port",
            "8080",
            "--ctx-size",
            str(context),
            "--n-predict",
            "8192",
            "--n-gpu-layers",
            "999",
            "--jinja",
            "--flash-attn",
            flash_attn_flag,
            "--cache-type-k",
            KV_CACHE_K,
            "--cache-type-v",
            KV_CACHE_V,
            "--parallel",
            PARALLEL or "1",
            "--api-key",
            API_KEY,
        ]
        if chat_template_path is not None:
            command.extend(
                ["--chat-template-file", str(chat_template_path)]
            )
        if draft_model_path is not None:
            command.extend(["--model-draft", str(draft_model_path)])
        if CHAT_TEMPLATE_KWARGS:
            # Hard thinking mode: force the model's thinking chain on for every
            # request (Qwen3.8 embedded template reads enable_thinking /
            # reasoning_effort from chat template kwargs).
            command.extend(["--chat-template-kwargs", CHAT_TEMPLATE_KWARGS])
        spec_type = SPEC_TYPE or ("draft-dflash" if draft_model_path is not None else "")
        if spec_type:
            # Muse Glimmer ships a DFlash block-diffusion drafter; without an
            # explicit spec type the draft model loads but stays idle.
            # NOTE: the type name is case-sensitive "draft-dflash" in b10375+
            # (common_speculative_type_from_name_map); the old uppercase
            # "DFLASH" threw "unknown speculative type" and killed the server
            # at arg-parse time -- that was the v6 "crash", not SM75.
            command.extend(["--spec-type", spec_type])
        if draft_model_path is not None:
            if SPEC_DRAFT_N_MAX:
                command.extend(["--spec-draft-n-max", SPEC_DRAFT_N_MAX])
            # Default draft KV is f16 (2.68 GiB @131k for the 5-layer 8-head
            # DFlash drafter) which pressured the 16 GiB T4s into OOM during
            # the v6 attempt; quantize it like the target cache.
            if SPEC_DRAFT_CACHE_K:
                command.extend(["--spec-draft-type-k", SPEC_DRAFT_CACHE_K])
            if SPEC_DRAFT_CACHE_V:
                command.extend(["--spec-draft-type-v", SPEC_DRAFT_CACHE_V])
            if SPEC_DRAFT_P_MIN:
                command.extend(["--spec-draft-p-min", SPEC_DRAFT_P_MIN])
            if SPEC_DRAFT_N_MIN:
                command.extend(["--spec-draft-n-min", SPEC_DRAFT_N_MIN])
        if TENSOR_SPLIT:
            command.extend(["--split-mode", SPLIT_MODE or "layer", "--tensor-split", TENSOR_SPLIT])
        elif count > 1:
            command.extend(
                ["--split-mode", SPLIT_MODE or "layer", "--tensor-split", ",".join(["1"] * count)]
            )
        if BATCH_SIZE:
            command.extend(["--batch-size", BATCH_SIZE])
        if UBATCH_SIZE:
            command.extend(["--ubatch-size", UBATCH_SIZE])
        if FIT_TARGET:
            # --fit-ctx pins the ctx upper bound so --fit trims batch/layers
            # instead of silently shrinking the context (fit default min-ctx is
            # only 4096).
            command.extend(
                ["--fit", "on", "--fit-target", FIT_TARGET, "--fit-ctx", str(context)]
            )
        if FIT_MODE == "off":
            # Explicit control: disable the auto-tuner entirely (it overrides
            # --batch-size/--ubatch-size to squeeze VRAM, which tanks prefill).
            command.extend(["--fit", "off"])
        if MMPROJ_OFFLOAD == "0":
            command.extend(["--no-mmproj-offload"])
        print(f"Starting llama-server with {context} token context", flush=True)
        log = SERVER_LOG.open("w", buffering=1)
        process = subprocess.Popen(
            command,
            stdout=log,
            stderr=subprocess.STDOUT,
            env=runtime_environment(library_dir),
        )
        if wait_for_health(process):
            print(f"llama-server is healthy (context={context})", flush=True)
            return process, context
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
        log.close()
        tail = SERVER_LOG.read_text(errors="replace")[-6000:]
        print(f"llama-server failed at context={context}:\n{tail}", flush=True)
    raise RuntimeError("llama-server failed to start; see /kaggle/working/llama-server.log")


def install_cloudflared():
    path = WORK / "cloudflared"
    urllib.request.urlretrieve(
        "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
        path,
    )
    path.chmod(0o755)
    return path


# llama-server (commit 64d528b) rejects Responses-API `function_call_output`
# blocks whose `type` is not exactly "input_text" (server-chat.cpp:206), but
# OpenAI-compatible clients send "output_text"/"text". Normalize to "input_text"
# before forwarding so tool-call image/multimodal flows do not 400 and abort.
def normalize_responses_body(raw):
    try:
        payload = json.loads(raw)
    except Exception:
        return raw
    items = payload.get("input")
    if isinstance(items, list):
        changed = False
        for item in items:
            if not isinstance(item, dict) or item.get("type") != "function_call_output":
                continue
            output = item.get("output")
            if isinstance(output, list):
                for block in output:
                    if isinstance(block, dict):
                        block_type = block.get("type")
                        if block_type is not None and block_type != "input_text":
                            block["type"] = "input_text"
                            changed = True
        if changed:
            return json.dumps(payload).encode()
    return raw


def start_proxy(upstream_host="127.0.0.1", upstream_port=8080, listen_port=8081):
    """Thin reverse proxy in front of llama-server that normalizes the
    Responses-API body; streams the upstream SSE response back unchanged."""

    class ResponsesProxy(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *args):
            pass

        def _forward(self):
            length = int(self.headers.get("Content-Length", 0) or 0)
            body = self.rfile.read(length) if length else b""
            is_responses = self.command == "POST" and self.path.rstrip("/").endswith("/responses")
            is_completions = self.command == "POST" and self.path.rstrip("/").endswith("/chat/completions")
            client_stream = False
            if body and (is_responses or is_completions):
                try:
                    client_stream = bool(json.loads(body).get("stream", False))
                except Exception:
                    client_stream = False
            if is_responses:
                body = normalize_responses_body(body)
            is_streaming = client_stream or is_responses
            # Tunnel-facing auth gate (independent of llama-server's own checks):
            # the early 200 commit for streaming happens BEFORE upstream auth,
            # so unauthenticated POSTs must be rejected right here â€” otherwise
            # the random public trycloudflare URL is an open relay that ties up
            # a connection/thread per request (and the 200 already sent would
            # mask upstream 401s).
            if (is_responses or is_completions) and self.headers.get("Authorization") != "Bearer " + API_KEY:
                payload = b'{"error":"unauthorized"}'
                if not client_stream:
                    self.send_response(401)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                else:
                    self.send_response(401)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Transfer-Encoding", "chunked")
                    self.end_headers()
                    self.wfile.write(b"%x\r\n" % len(payload))
                    self.wfile.write(payload)
                    self.wfile.write(b"\r\n0\r\n\r\n")
                self.wfile.flush()
                return
            upstream = http.client.HTTPConnection(upstream_host, upstream_port, timeout=1800)
            headers = {
                key: value
                for key, value in self.headers.items()
                if key.lower()
                not in ("host", "connection", "content-length", "transfer-encoding")
            }
            # Keepalive: llama-server does not emit a single byte â€” not even the
            # SSE headers â€” until the first token, so a long prefill (>100s)
            # would otherwise trip Cloudflare's tunnel timeout (HTTP 524). For
            # every streaming request (SSE chat completions included) we commit
            # the client response immediately (200, chunked) and heartbeat every
            # 20s with an SSE comment (streaming client) or a whitespace chunk
            # (buffered client) â€” both ignored by the client but they reset the
            # tunnel's inactivity timer.
            done = [False]
            last_write = [time.monotonic()]
            write_lock = threading.Lock()

            def keepalive():
                while not done[0]:
                    if time.monotonic() - last_write[0] >= 20:
                        payload = b": ping\n\n" if client_stream else b"\n"
                        try:
                            with write_lock:
                                self.wfile.write(b"%x\r\n" % len(payload))
                                self.wfile.write(payload)
                                self.wfile.write(b"\r\n")
                                self.wfile.flush()
                            last_write[0] = time.monotonic()
                        except Exception:
                            return
                    time.sleep(1)

            try:
                if is_streaming:
                    # Commit 200 now. llama-server reports generation failures
                    # inside a 200 body anyway, so we lose nothing by committing
                    # early, and the tunnel sees a byte the moment the request
                    # arrives (prevents HTTP 524 during long thinking prefill).
                    self.send_response(200)
                    self.send_header("Content-Type", "text/event-stream" if client_stream else "application/json")
                    self.send_header("Cache-Control", "no-cache")
                    self.send_header("Transfer-Encoding", "chunked")
                    self.end_headers()
                    thread = threading.Thread(target=keepalive, daemon=True)
                    thread.start()
                upstream.request(self.command, self.path, body=body, headers=headers)
                response = upstream.getresponse()
                if not is_streaming:
                    self.send_response(response.status)
                    for key, value in response.getheaders():
                        if key.lower() in (
                            "connection",
                            "transfer-encoding",
                            "content-length",
                            "keep-alive",
                            "proxy-connection",
                        ):
                            continue
                        self.send_header(key, value)
                    self.send_header("Transfer-Encoding", "chunked")
                    self.end_headers()
                # Forward upstream data with PER-LINE granularity and flush after
                # every line. response.read(65536) (the old code) blocks until
                # 64 KiB accumulate, so tokens arrived in big delayed bursts and
                # chat never felt realtime. SSE is line-delimited, so iterating
                # lines keeps per-token latency; non-SSE bodies still pass
                # through unchanged (lines are just shorter reads).
                for line in response:
                    last_write[0] = time.monotonic()
                    with write_lock:
                        self.wfile.write(b"%x\r\n" % len(line))
                        self.wfile.write(line)
                        self.wfile.write(b"\r\n")
                        self.wfile.flush()
                # Terminate the chunked stream. done[] is set FIRST so the
                # keepalive heartbeat can never append a stray chunk after the
                # terminal frame (race observed by security review).
                with write_lock:
                    done[0] = True
                    self.wfile.write(b"0\r\n\r\n")
                    self.wfile.flush()
            except Exception:
                try:
                    with write_lock:
                        self.wfile.write(b"0\r\n\r\n")
                        self.wfile.flush()
                except Exception:
                    pass
            finally:
                done[0] = True
                upstream.close()
                self.close_connection = True

        def do_GET(self):
            self._forward()

        def do_POST(self):
            self._forward()

        def do_PUT(self):
            self._forward()

        def do_DELETE(self):
            self._forward()

        def do_OPTIONS(self):
            self._forward()

        def do_HEAD(self):
            self._forward()

    server = http.server.ThreadingHTTPServer(("127.0.0.1", listen_port), ResponsesProxy)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"Responses-API proxy listening on 127.0.0.1:{listen_port}", flush=True)
    return server


def start_tunnel(cloudflared):
    log = CLOUDFLARED_LOG.open("w", buffering=1)
    process = subprocess.Popen(
        [
            str(cloudflared),
            "tunnel",
            "--url",
            "http://127.0.0.1:8081",
            "--no-autoupdate",
        ],
        stdout=log,
        stderr=subprocess.STDOUT,
    )
    deadline = time.time() + 180
    pattern = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
    while time.time() < deadline:
        if process.poll() is not None:
            break
        log.flush()
        content = CLOUDFLARED_LOG.read_text(errors="replace")
        match = pattern.search(content)
        if match:
            return process, match.group(0)
        time.sleep(2)
    log.flush()
    tail = CLOUDFLARED_LOG.read_text(errors="replace")[-6000:]
    raise RuntimeError(f"Cloudflare tunnel failed to start:\n{tail}")


def probe_api_access():
    """Diagnostic: can the container's own Kaggle credentials call the web
    /api/i/ endpoints (GetKernelViewModel / ListKernelVersions)? Those expose
    a version's run.id, which the non-interactive SAVE_AND_RUN_ALL push cannot
    return directly. Publishes only token prefixes, HTTP statuses, and session
    ids to ntfy -- never full token values."""
    import http.cookiejar as _cookiejar
    import urllib.error as _uerror

    def candidates():
        found = {}
        for name in ("KAGGLE_ACCESS_TOKEN", "KAGGLE_API_TOKEN", "KAGGLE_KEY"):
            value = os.environ.get(name)
            if value:
                found["env:" + name] = value
        for path in (
            "/kaggle/kaggle-access-token",
            "/root/.kaggle/kaggle.json",
            "/home/kaggle/.kaggle/kaggle.json",
            "/root/.kaggle/credentials.json",
        ):
            p = Path(path)
            if not p.exists():
                continue
            try:
                raw = p.read_text(encoding="utf-8", errors="ignore").strip()
            except Exception:
                continue
            if p.name.endswith(".json"):
                try:
                    d = json.loads(raw)
                    value = (
                        d.get("key")
                        or d.get("access_token")
                        or d.get("refresh_token")
                        or d.get("token")
                    )
                except Exception:
                    value = None
            else:
                value = raw
            if value:
                found["file:" + path] = value
        return found

    def resolve(token):
        jar = _cookiejar.CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        try:
            opener.open(
                urllib.request.Request(
                    "https://www.kaggle.com/",
                    headers={"Authorization": "Bearer " + token, "User-Agent": "Mozilla/5.0"},
                ),
                timeout=20,
            )
        except Exception:
            pass
        xsrf = None
        for cookie in jar:
            if cookie.name in ("XSRF-TOKEN", "CSRF-TOKEN"):
                xsrf = urllib.request.quote(cookie.value)
        headers = {
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0",
        }
        if xsrf:
            headers["X-XSRF-TOKEN"] = xsrf

        def post(method, body):
            request = urllib.request.Request(
                "https://www.kaggle.com/api/i/" + method,
                data=json.dumps(body).encode(),
                headers=headers,
            )
            try:
                with urllib.request.urlopen(request, timeout=20) as response:
                    return "OK", response.status, response.read(4000).decode("utf-8", "ignore")
            except _uerror.HTTPError as exc:
                return "HTTPError", exc.code, exc.read(300).decode("utf-8", "ignore")
            except Exception as exc:
                return "EXC", None, str(exc)[:150]

        user = os.environ.get("KAGGLE_USERNAME", "iyppmx")
        slug = "qwen3-8-27b-ud-q4-k-xl-mtp"
        info = {"xsrf": bool(xsrf)}
        status, code, body = post(
            "kernels.LegacyKernelsService/GetKernelViewModel",
            {"authorUserName": user, "kernelSlug": slug, "tab": "output"},
        )
        info["vm"] = "%s %s" % (status, code)
        if status != "OK":
            info["body"] = body[:200]
            return info
        try:
            view = json.loads(body)
        except Exception:
            info["body"] = body[:200]
            return info
        kernel_id = (view.get("kernel") or {}).get("id")
        info["kernel_id"] = kernel_id
        if not kernel_id:
            return info
        status2, code2, body2 = post(
            "kernels.KernelsService/ListKernelVersions",
            {"kernelId": kernel_id, "sortOption": "VERSION_ID", "pageSize": 30},
        )
        info["versions"] = "%s %s" % (status2, code2)
        if status2 == "OK":
            try:
                items = json.loads(body2).get("items") or []
                info["runs"] = [
                    {
                        "v": it.get("version", {}).get("versionNumber"),
                        "session_id": (it.get("run") or {}).get("id"),
                    }
                    for it in items[:8]
                ]
            except Exception as exc:
                info["versions_parse"] = str(exc)[:100]
        return info

    results = {}
    for label, token in candidates().items():
        try:
            results[label] = {"prefix": token[:8], "len": len(token)}
            results[label].update(resolve(token))
        except Exception as exc:
            results[label] = {"error": str(exc)[:150]}
    return results


def main():
    # The local stop script requires this exact marker before it is allowed to
    # cancel a numeric Kaggle kernel session. Keep it free of transient secrets.
    print(
        f"SERVING_NOTEBOOK_FINGERPRINT: {SERVING_NOTEBOOK_FINGERPRINT}",
        flush=True,
    )
    publish("boot")
    try:
        publish("api_probe", results=probe_api_access())
    except Exception as exc:
        publish("api_probe", error=str(exc)[:300])
    count = gpu_count()
    if count < 1:
        raise RuntimeError("No NVIDIA GPU is attached to this Kaggle session")
    ensure_model_artifacts([MODEL_FILE, MMPROJ_FILE, DRAFT_FILE])
    model_path, mmproj_path = find_model_artifacts()
    publish("runtime_check", gpu_count=count)
    cached_runtime = find_cached_runtime()
    if cached_runtime:
        server_path, cloudflared, library_dir, manifest = cached_runtime
        publish(
            "runtime_cache_hit",
            llama_cpp_commit=manifest["source"]["llama_cpp_commit"],
            cuda=manifest["target"]["cuda_toolkit"],
            architectures=manifest["target"]["cuda_architectures"],
        )
        runtime_cached = True
    else:
        publish("building", gpu_count=count, llama_cpp_commit=LLAMA_CPP_COMMIT)
        server_path, library_dir = build_llama_cpp()
        cloudflared = install_cloudflared()
        runtime_cached = False
    publish("loading", runtime_cached=runtime_cached)
    server, context = start_server(
        model_path, mmproj_path, count, server_path, library_dir
    )
    # Report what llama-server actually did (offload layout, KV cache size,
    # cache types, batch/ubatch, ctx) so the OOM ladder can be tuned from
    # get_session_logs without guessing. SERVER_LOG is truncated per start
    # attempt, so this always reflects the run that became healthy.
    log_lines = SERVER_LOG.read_text(errors="replace").splitlines()
    for line in log_lines:
        if any(k in line for k in ("offload", "VRAM", "cache_type", "tensor_split", "split_mode", "n_batch", "n_ubatch", "ctx_size", "llama_kv_cache", "model buffer", "CPU buffer", "KV buffer", "flash_attn", "compute buffer", "n_ctx_per_seq", "buffer size", "is_swa")) or line.startswith("llama_model_load:") or line.startswith("llm_load_tensors:") or line.startswith("llama_kv_cache_unified"):
            print(line, flush=True)
    print(
        subprocess.check_output(
            ["nvidia-smi", "--query-gpu=index,memory.used,memory.total", "--format=csv,noheader"],
            text=True,
        ),
        flush=True,
    )
    start_proxy(upstream_host="127.0.0.1", upstream_port=8080, listen_port=8081)
    tunnel, url = start_tunnel(cloudflared)
    publish(
        "ready",
        url=url,
        context=context,
        gpu_count=count,
        model=MODEL_ALIAS,
        runtime_cached=runtime_cached,
        llama_cpp_commit=LLAMA_CPP_COMMIT,
    )
    print(f"READY: {url}/v1 (context={context}, GPUs={count})", flush=True)

    started = time.time()
    while True:
        if server.poll() is not None:
            publish("failed", component="llama-server", returncode=server.returncode)
            raise RuntimeError("llama-server exited unexpectedly")
        if tunnel.poll() is not None:
            publish("failed", component="cloudflared", returncode=tunnel.returncode)
            raise RuntimeError("cloudflared exited unexpectedly")
        elapsed = int((time.time() - started) / 60)
        print(f"keepalive: serving for {elapsed} minutes", flush=True)
        time.sleep(60)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        publish("failed", error=str(exc))
        raise
