import json
import re
import time
import urllib.request

SYSTEM = '''Infer a single coherent transformation from the ARC demonstrations.
Colours are integer labels 0..9. Do not memorize examples, task IDs or expected test outputs.
Reason about objects, relations and the rule, then implement deterministic Python.
Return the complete program in one final ```python block, defining solve(grid) -> list[list[int]].
The program must work on every training input and on unseen inputs. Helpers are allowed.
Available imports: numpy, math, itertools, functools, collections. np is preloaded.
No filesystem, network, subprocesses or external packages. Grids are at most 30x30.
Do not run tests at module scope; only define functions, constants and imports.'''

DUCK_SYSTEM = SYSTEM + '''
You may first explore with generic Python: return JSON {"action":"explore","code":"..."}.
An exploration is a fresh process, with TASK as a Python dict containing demonstrations and test INPUTS.
Use print for bounded observations. After feedback, emit the final solve program.
Temporary helper state does not persist, so include all final helpers in your program.'''


def extract_program(text):
    # Reasoning-channel code is never promoted to the final candidate.
    text = text.rsplit('</think>', 1)[-1]
    matches = re.findall(r'```(?:python|py)?\s*\n(.*?)```', text, flags=re.S)
    if matches:
        return matches[-1].strip()
    if text.lstrip().startswith(('def ', 'import ', 'from ')) and 'def solve(' in text:
        return text.strip()
    raise ValueError('no complete final Python block')


class OpenAIModel:
    """OpenAI-compatible local server. Actual response, usage and stop reason are archived."""
    def __init__(self, url='http://127.0.0.1:8000/v1', model='arc-model', max_tokens=8192,
                 temperature=1.0, reasoning_effort='medium', backend='llama', seed=0):
        self.url, self.model = url.rstrip('/'), model
        self.max_tokens, self.temperature = max_tokens, temperature
        self.effort, self.backend, self.seed = reasoning_effort, backend, seed

    def generate(self, messages, remaining):
        body = {'model': self.model, 'messages': messages, 'max_tokens': self.max_tokens,
                'temperature': self.temperature, 'top_p': .95, 'seed': self.seed}
        if self.backend == 'llama':
            body['chat_template_kwargs'] = {'reasoning_effort': self.effort, 'enable_thinking': True}
        else:
            body['chat_template_kwargs'] = {'reasoning_effort': self.effort, 'enable_thinking': True}
            body['top_k'] = 20
        req = urllib.request.Request(self.url + '/chat/completions', data=json.dumps(body).encode(),
                                     headers={'Content-Type': 'application/json'})
        start = time.monotonic()
        with urllib.request.urlopen(req, timeout=max(.1, min(remaining, 600))) as r:
            raw = json.load(r)
        choice = raw['choices'][0]
        return {'text': choice['message'].get('content') or '',
                'reasoning': choice['message'].get('reasoning_content') or choice['message'].get('reasoning') or '',
                'finish_reason': choice.get('finish_reason'), 'usage': raw.get('usage', {}),
                'seconds': time.monotonic()-start, 'model': raw.get('model', self.model)}


class ReplayModel:
    """Deterministic fixture provider for infrastructure tests ONLY; never model evidence."""
    def __init__(self, responses):
        self.responses = iter(responses)

    def generate(self, messages, remaining):
        return {'text': next(self.responses), 'seconds': 0, 'finish_reason': 'stop',
                'usage': {}, 'model': 'FIXTURE-NOT-QWEN'}
