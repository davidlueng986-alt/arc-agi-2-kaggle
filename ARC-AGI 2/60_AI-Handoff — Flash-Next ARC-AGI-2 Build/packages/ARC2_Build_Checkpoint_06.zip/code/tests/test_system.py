import json
from pathlib import Path
import tempfile
import unittest
from arcsolver.data import clean_task, fixed_subset, grid
from arcsolver.executor import Executor
from arcsolver.verifier import verify
from arcsolver.search import Solver, SearchConfig, select
from arcsolver.model import ReplayModel, extract_program
from arcsolver.evaluate import metrics, run_evaluation, validate_submission, atomic_json

TASK={'train':[{'input':[[1,2],[3,4]],'output':[[2,1],[4,3]]},
               {'input':[[5,6,7]],'output':[[7,6,5]]}],
      'test':[{'input':[[8,0]],'output':[[0,8]]}]}
WRONG='```python\ndef solve(g): return g\n```'
RIGHT='```python\ndef solve(g): return [row[::-1] for row in g]\n```'


class SystemTests(unittest.TestCase):
    def test_label_firewall(self):
        self.assertNotIn('output',clean_task(TASK)['test'][0])
        with tempfile.TemporaryDirectory() as d:
            Solver(ReplayModel([RIGHT]),Executor(),SearchConfig(candidates=1,repairs=0)).solve('x',TASK,d)
            self.assertNotIn('"output": [[0, 8]]',Path(d,'x','calls.json').read_text())

    def test_generation_failure_archives_prompt_and_reserves_verification(self):
        class ErrorFixture:
            def generate(self,messages,remaining):raise TimeoutError('fixture timeout')
        with tempfile.TemporaryDirectory() as d:
            r=Solver(ErrorFixture(),Executor(),SearchConfig(candidates=1,repairs=0,task_seconds=30)).solve('x',TASK,d)
            call=json.loads(Path(d,'x','calls.json').read_text())[0]
            self.assertEqual(call['error'],'TimeoutError');self.assertIn('messages',call)
            self.assertLess(call['requested_wall_seconds'],30)
            seen=json.loads(call['messages'][1]['content'].split('\nIndependent hypothesis')[0])
            self.assertNotIn('output',seen['test'][0]);self.assertEqual(r['generated_candidates'],0)

    def test_exact_verifier_not_cell_similarity(self):
        e=Executor().run('def solve(g): return g',[p['input'] for p in TASK['train']])
        v=verify(e,TASK['train']);self.assertFalse(v['exact']);self.assertEqual(v['fit'],0)
        self.assertEqual(v['pairs'][0]['wrong_cells'],4)

    def test_repair_end_to_end_and_lineage(self):
        with tempfile.TemporaryDirectory() as d:
            s=Solver(ReplayModel([WRONG,RIGHT]),Executor(),SearchConfig(candidates=1,repairs=1))
            r=s.solve('x',TASK,d)
            self.assertTrue(r['train_exact']);self.assertEqual(r['repair_iterations'],1)
            self.assertEqual(r['archive'][1]['parent'],r['archive'][0]['id'])
            self.assertEqual(r['predictions'][0]['attempt_1'],[[0,8]])
            m=metrics([r],{'x':[[[0,8]]]})
            self.assertEqual(m['public_eval_pass_at_1'],1)
            self.assertIsNone(m['gpu_device_hours'])

    def test_file_network_process_isolation(self):
        for expression in ["open('/etc/passwd').read()", "__import__('socket').socket()", "__import__('os').fork()"]:
            e=Executor().run('def solve(g): return '+expression,[[[1]]])
            self.assertFalse(e.get('error')=='sandbox_unavailable',e)
            self.assertIn(e['results'][0]['error'],['PermissionError','ImportError','OSError'])

    def test_timeout(self):
        e=Executor().run('def solve(g):\n while True: pass',[[[1]]],timeout=.5)
        self.assertEqual(e['error'],'timeout')

    def test_raw_output_flood_is_bounded(self):
        e=Executor().run('import os\ndef solve(g):\n while True: os.write(1,b"x"*8192)',[[[1]]],timeout=2)
        self.assertEqual(e['error'],'output_limit')

    def test_forged_worker_result_is_validated_in_parent(self):
        for raw in [{'results':[{'output':[[99]]}]},{'results':[]},[1]]:
            src='import os\ndef solve(g):\n os.write(1,'+repr(json.dumps(raw).encode())+')\n os._exit(0)'
            self.assertEqual(Executor().run(src,[[[1]]])['error'],'invalid_worker_protocol')

    def test_malformed_outputs(self):
        for literal in ['[[1.0]]','[[True]]','[[10]]','[]','[[1],[1,2]]']:
            e=Executor().run('def solve(g): return '+literal,[[[1]]])
            self.assertEqual(e['results'][0]['error'],'ValueError')

    def test_independent_state(self):
        src='counter=0\ndef solve(g):\n global counter\n counter+=1\n return [[counter]]'
        e=Executor().run(src,[[[0]],[[0]]])
        self.assertEqual([p['output'] for p in e['results']],[[[1]],[[1]]])
        src='def solve(g):\n np._arc_counter=getattr(np,"_arc_counter",0)+1\n return [[np._arc_counter]]'
        e=Executor().run(src,[[[0]],[[0]]])
        self.assertEqual([p['output'] for p in e['results']],[[[1]],[[1]]])

    def test_shape_feedback(self):
        e=Executor().run('def solve(g): return [[0]]',[[[1,2]]])
        v=verify(e,[{'input':[[1,2]],'output':[[2,1]]}]);self.assertEqual(v['pairs'][0]['expected_shape'],[1,2])

    def test_code_parser_ignores_thinking(self):
        self.assertEqual(extract_program('<think>```python\nbad\n```</think>'+RIGHT),'def solve(g): return [row[::-1] for row in g]')
        with self.assertRaises(ValueError):extract_program('<think>```python\nbad\n```</think>')

    def test_model_http_contract_and_context_budget(self):
        from http.server import BaseHTTPRequestHandler, HTTPServer
        import threading
        from arcsolver.model import OpenAIModel
        requests=[]
        class Handler(BaseHTTPRequestHandler):
            count=1500
            def log_message(self,*args):pass
            def do_POST(self):
                body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                requests.append((self.path,body))
                answer=({'count':self.count,'max_model_len':2048,'tokens':[]}
                        if self.path=='/tokenize' else
                        {'choices':[{'message':{'content':RIGHT},'finish_reason':'stop'}],
                         'model':'HTTP-CONTRACT-FIXTURE','usage':{'completion_tokens':12}})
                self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers()
                self.wfile.write(json.dumps(answer).encode())
        server=HTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            m=OpenAIModel(url=f'http://127.0.0.1:{server.server_port}/v1',backend='vllm',max_tokens=8192)
            messages=[{'role':'user','content':json.dumps(clean_task(TASK))}]
            r=m.generate(messages,5)
            self.assertEqual(requests[-1][0],'/v1/chat/completions')
            self.assertEqual(requests[-1][1]['max_tokens'],516)
            self.assertEqual(requests[-1][1]['reasoning_effort'],'medium')
            self.assertEqual(requests[-1][1]['messages'],messages)
            self.assertEqual(r['token_budget']['prompt_tokens'],1500)
            Handler.count=2000
            with self.assertRaisesRegex(ValueError,'context budget exhausted'):m.generate(messages,5)
            self.assertEqual(requests[-1][0],'/tokenize')
        finally:server.shutdown();server.server_close();thread.join()

    def test_stream_collects_reasoning_final_and_usage(self):
        from http.server import BaseHTTPRequestHandler,HTTPServer
        import threading
        from arcsolver.model import OpenAIModel
        received=[]
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):
                received.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
                self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
                for data in [{'choices':[{'delta':{'reasoning_content':'fixture thought'}}]},
                             {'choices':[{'delta':{'content':RIGHT},'finish_reason':'stop'}]},
                             {'choices':[],'usage':{'completion_tokens':12}}]:
                    self.wfile.write(b'data: '+json.dumps(data).encode()+b'\n\n')
                self.wfile.write(b'data: [DONE]\n\n')
        server=HTTPServer(('127.0.0.1',0),Handler)
        th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
        try:
            m=OpenAIModel(url=f'http://127.0.0.1:{server.server_port}/v1',backend='vllm',
                          count_context=False,stream=True,thinking_token_budget=4096)
            r=m.generate([{'role':'user','content':'fixture'}],3)
            self.assertEqual(r['text'],RIGHT);self.assertEqual(r['reasoning'],'fixture thought')
            self.assertEqual(r['usage']['completion_tokens'],12);self.assertEqual(r['finish_reason'],'stop')
            self.assertFalse(r['partial_generation']);self.assertTrue(received[0]['stream'])
            self.assertEqual(received[0]['thinking_token_budget'],4096)
        finally:server.shutdown();server.server_close();th.join()

    def test_stream_deadline_keeps_evidence_without_promoting_thoughts(self):
        from http.server import BaseHTTPRequestHandler,HTTPServer
        import threading,time
        from arcsolver.model import OpenAIModel
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):
                self.rfile.read(int(self.headers['Content-Length']))
                self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
                self.wfile.write(b'data: '+json.dumps({'choices':[{'delta':{'reasoning':RIGHT}}]}).encode()+b'\n\n')
                self.wfile.flush();time.sleep(.5)
        server=HTTPServer(('127.0.0.1',0),Handler)
        th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
        try:
            m=OpenAIModel(url=f'http://127.0.0.1:{server.server_port}/v1',backend='vllm',
                          count_context=False,stream=True)
            t=time.monotonic();r=m.generate([{'role':'user','content':'fixture'}],.2)
            self.assertLess(time.monotonic()-t,1)
            self.assertEqual(r['finish_reason'],'deadline');self.assertTrue(r['partial_generation'])
            self.assertEqual(r['reasoning'],RIGHT);self.assertEqual(r['text'],'')
            with self.assertRaises(ValueError):extract_program(r['text'])
        finally:server.shutdown();server.server_close();th.join()

    def test_diverse_selection_and_no_repair_vote_inflation(self):
        def c(root,out,exact=True):
            return {'root':root,'outputs':[out],'complexity':4,'verification':{'exact':exact,'fit':int(exact),'cell_accuracy':int(exact)}}
        pool=[c(0,[[1]])]*5+[c(1,[[2]]),c(2,[[2]]),c(3,[[3]],False)]
        p=select(pool,clean_task(TASK))[0]
        self.assertEqual(p['attempt_1'],[[2]]);self.assertEqual(p['attempt_2'],[[1]])

    def test_subset_no_label_dependence(self):
        tasks={str(i):clean_task(TASK) for i in range(20)}
        self.assertEqual(fixed_subset(tasks,8),fixed_subset(tasks,8))
        self.assertEqual(len(set(fixed_subset(tasks,8))),8)

    def test_duplicate_proposals_are_counted(self):
        with tempfile.TemporaryDirectory() as d:
            r=Solver(ReplayModel([WRONG,WRONG]),Executor(),
                     SearchConfig(candidates=2,repairs=0)).solve('x',TASK,d)
            self.assertEqual(r['generated_candidates'],2)
            self.assertEqual(r['archived_candidates'],1)
            self.assertEqual(r['duplicate_programs'],1)

    def test_duck_exploration(self):
        with tempfile.TemporaryDirectory() as d:
            m=ReplayModel([json.dumps({'action':'explore','code':'print(len(TASK["train"]))'}),RIGHT])
            r=Solver(m,Executor(),SearchConfig(mode='duck',candidates=1,repairs=0)).solve('x',TASK,d)
            self.assertTrue(r['train_exact']);self.assertEqual(r['model_calls'],2)

    def test_duck_fenced_json_exploration(self):
        with tempfile.TemporaryDirectory() as d:
            action='```json\n'+json.dumps({'action':'explore','code':'print(len(TASK["train"]))'})+'\n```'
            r=Solver(ReplayModel([action,RIGHT]),Executor(),SearchConfig(mode='duck',candidates=1,repairs=0)).solve('x',TASK,d)
            self.assertTrue(r['train_exact']);self.assertEqual(r['model_calls'],2)

    def test_evaluation_partial_denominator_and_submission(self):
        with tempfile.TemporaryDirectory() as d:
            s=Solver(ReplayModel([RIGHT]),Executor(),SearchConfig(candidates=1,repairs=0))
            tasks={'x':clean_task(TASK)}
            m=run_evaluation(tasks,{'x':[[[0,8]]]},s,d,30)
            self.assertEqual(m['scheduled_public_eval_pass_at_2'],1)
            self.assertTrue(validate_submission(json.loads(Path(d,'submission.json').read_text()),tasks))

    def test_concurrent_atomic_checkpoints(self):
        from concurrent.futures import ThreadPoolExecutor
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'shared.json'
            def writer(n):
                for i in range(50):atomic_json(p,{'writer':n,'iteration':i,'payload':[i]*1000})
            with ThreadPoolExecutor(max_workers=4) as pool:
                for f in [pool.submit(writer,n) for n in range(4)]:f.result()
            r=json.loads(p.read_text())
            self.assertEqual(r['iteration'],49);self.assertEqual(r['payload'],[49]*1000)
            self.assertEqual(list(Path(d).glob('*.tmp')),[])

    def test_parallel_task_pipeline_and_submission_integrity(self):
        import threading
        barrier=threading.Barrier(2)
        class ConcurrentFixture:
            def generate(self,messages,remaining):
                barrier.wait(timeout=3)
                return {'text':RIGHT,'seconds':0,'finish_reason':'stop','usage':{},'model':'PARALLEL-FIXTURE-NOT-QWEN'}
        with tempfile.TemporaryDirectory() as d:
            tasks={k:clean_task(TASK) for k in ['x','y']}
            labels={k:[[[0,8]]] for k in tasks}
            s=Solver(ConcurrentFixture(),Executor(),SearchConfig(candidates=1,repairs=0,task_seconds=10))
            m=run_evaluation(tasks,labels,s,d,20,concurrency=2)
            self.assertEqual(m['completed_tasks'],2);self.assertTrue(m['full_set_complete'])
            self.assertEqual(m['task_concurrency'],2);self.assertEqual(m['public_eval_pass_at_1'],1)
            self.assertTrue(validate_submission(json.loads(Path(d,'submission.json').read_text()),tasks))

    def test_submission_snapshot_never_requests_ordinary_execution(self):
        import os,subprocess,sys
        script=Path(__file__).resolve().parents[1]/'scripts/push_kaggle.py'
        if not script.exists():
            # Embedded Kaggle audit deliberately contains solver modules, not
            # deployment tools. Deployment contract is checked on the build host.
            self.skipTest('deployment script is host-only')
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);meta=p/'kernel-metadata.json';ledger=p/'ledger.json';capture=p/'args.json'
            meta.write_text(json.dumps({'id':'fixture/not-a-kaggle-request','enable_gpu':False}))
            ledger.write_text(json.dumps({'runs':[{'requested_timeout_seconds':6900}]}))
            (p/'kaggle.py').write_text('import json,os,sys,pathlib\npathlib.Path(os.environ["ARC_PUSH_TEST_ARGS"]).write_text(json.dumps(sys.argv))')
            env=dict(os.environ,PYTHONPATH=str(p),ARC_PUSH_TEST_ARGS=str(capture))
            cmd=[sys.executable,str(script),'--folder',d,'--seconds','43200','--ledger',str(ledger)]
            cp=subprocess.run(cmd+['--submission-snapshot'],env=env,capture_output=True,text=True)
            self.assertEqual(cp.returncode,0,cp.stderr)
            args=json.loads(capture.read_text())
            self.assertIn('--no-run',args);self.assertNotIn('--accelerator',args)
            self.assertEqual(sum(x['requested_timeout_seconds'] for x in json.loads(ledger.read_text())['runs']),6900)
            capture.unlink()
            cp=subprocess.run(cmd+['--gpu'],env=env,capture_output=True,text=True)
            self.assertNotEqual(cp.returncode,0);self.assertFalse(capture.exists())
            cp=subprocess.run(cmd,env=env,capture_output=True,text=True)
            self.assertEqual(cp.returncode,0,cp.stderr)
            self.assertFalse(json.loads(meta.read_text())['enable_gpu'])
            self.assertEqual(json.loads(meta.read_text())['machine_shape'],'None')


if __name__=='__main__':unittest.main()
