"""Audit recorded proposals and selection without regenerating or reading labels."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parents[1]))
from arcsolver.data import digest
from arcsolver.evaluate import atomic_json


def audit(root):
    rows=[];failure=Counter();tokens=Counter();response_count=0
    for path in sorted(Path(root).rglob('result.json')):
        r=json.loads(path.read_text())
        if not isinstance(r,dict) or 'archive' not in r:continue
        calls=json.loads(path.with_name('calls.json').read_text())
        responses=[c for c in calls if 'text' in c]
        response_count+=len(responses)
        explorations=sum('exploration' in c for c in responses)
        proposals=len(responses)-explorations
        duplicates=sum(bool(c.get('duplicate_code')) for c in responses)
        for c in responses:
            for key,value in c.get('usage',{}).items():
                if isinstance(value,(int,float)):tokens[key]+=value
        failure.update(r['failures'])
        fit=[c for c in r['archive'] if c['verification']['exact']]
        for i,p in enumerate(r['predictions']):
            fitting_outputs={digest(c['outputs'][i]) for c in fit
                             if c.get('outputs') and c['outputs'][i] is not None}
            rows.append({'task_id':r['task_id'],'test_index':i,
                         'independent_train_fit_roots':len({c['root'] for c in fit}),
                         'distinct_fitting_test_outputs':len(fitting_outputs),
                         'distinct_final_attempts':p['attempt_1']!=p['attempt_2'],
                         'selected_first_has_exact_fit_support':digest(p['attempt_1']) in fitting_outputs,
                         'proposal_count_from_raw_calls':proposals,
                         'duplicate_programs':duplicates,
                         'archive_count':len(r['archive']),
                         'generation_error_calls':sum(bool(c.get('error')) for c in calls),
                         'truncated_responses':sum(c.get('finish_reason')=='length' for c in responses)})
    return {'protocol':'post-generation label-free audit; no new model calls',
            'recorded_test_outputs':len(rows),'recorded_tasks':len({r['task_id'] for r in rows}),
            'has_solver_result_evidence':bool(rows),'recorded_model_responses':response_count,
            'has_model_trace_evidence':bool(response_count),
            'absence_means':('no recorded solve results, not zero model accuracy' if not rows else
                             'solve records contain no completed model response' if not response_count else None),
            'usage_sums_over_calls':dict(tokens),'failure_counts_per_candidate_or_call':dict(failure),
            'rows':rows,'row_scope':'one row per test output; task proposal counts repeat on multi-test tasks'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--traces',required=True);p.add_argument('--out',required=True)
    a=p.parse_args();r=audit(a.traces);atomic_json(a.out,r)
    print(json.dumps({k:v for k,v in r.items() if k!='rows'},indent=2))
