"""Read-only status polling, then preserve the completed version's logs/artifacts.
Requires the separate Kaggle CLI requirements and credentials in the environment.
Never pushes or starts a notebook, and never prints credentials.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
from kaggle.api.kaggle_api_extended import KaggleApi

p=argparse.ArgumentParser();p.add_argument('--kernel',required=True)
p.add_argument('--out',required=True);p.add_argument('--poll-seconds',type=int,default=30)
p.add_argument('--maximum-seconds',type=int,default=7200);a=p.parse_args()
out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
api=KaggleApi();api.authenticate();start=time.monotonic();last=None
terminal={'COMPLETE','ERROR','CANCEL_ACKNOWLEDGED','CANCELLED'}
while time.monotonic()-start<a.maximum_seconds:
    try:
        status=str(api.kernels_status(a.kernel).status).split('.')[-1]
        if status!=last:
            info={'kernel':a.kernel,'status':status,'epoch':time.time()}
            (out/'collector-status.json').write_text(json.dumps(info,indent=2))
            print(json.dumps(info),flush=True);last=status
        if status in terminal:break
    except Exception as exc:
        print(json.dumps({'status_poll_error':type(exc).__name__}),flush=True)
    time.sleep(max(5,min(60,a.poll_seconds)))
else:raise SystemExit('collector deadline; no mutation performed')
base=[sys.executable,'-m','kaggle','kernels']
with (out/'final-log.json').open('w') as f:
    subprocess.run(base+['logs',a.kernel],stdout=f,stderr=subprocess.STDOUT,check=True)
subprocess.run(base+['output',a.kernel,'-p',str(out),
    '--file-pattern','arc2-results/|submission.json','-q','--page-size','200'],check=True)
print(json.dumps({'status':'collected','files':sum(p.is_file() for p in out.rglob('*'))}),flush=True)
