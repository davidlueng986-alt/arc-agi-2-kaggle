import argparse
import json
from pathlib import Path
from .data import load_tasks, fixed_subset, digest
from .executor import Executor
from .model import OpenAIModel
from .search import Solver, SearchConfig
from .evaluate import run_evaluation, atomic_json


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--tasks',required=True);p.add_argument('--labels')
    p.add_argument('--out',required=True);p.add_argument('--config',required=True)
    p.add_argument('--url',default='http://127.0.0.1:8000/v1')
    p.add_argument('--subset',type=int,default=0);p.add_argument('--budget',type=float,default=3600)
    p.add_argument('--gpu-count',type=int,default=0)
    p.add_argument('--concurrency',type=int,default=1)
    args=p.parse_args(); config=json.loads(Path(args.config).read_text())
    tasks,labels=load_tasks(args.tasks)
    if args.labels:
        labels=json.loads(Path(args.labels).read_text())
    if args.subset:
        tasks={k:tasks[k] for k in fixed_subset(tasks,args.subset)}
    atomic_json(Path(args.out)/'run_config.json',dict(config,task_ids=list(tasks),task_hash=digest(tasks)))
    model=OpenAIModel(url=args.url,**config.get('model',{}))
    solver=Solver(model,Executor(),SearchConfig(**config.get('search',{})))
    print(json.dumps(run_evaluation(tasks,labels,solver,args.out,args.budget,args.gpu_count,concurrency=args.concurrency),indent=2))


if __name__=='__main__':
    main()
