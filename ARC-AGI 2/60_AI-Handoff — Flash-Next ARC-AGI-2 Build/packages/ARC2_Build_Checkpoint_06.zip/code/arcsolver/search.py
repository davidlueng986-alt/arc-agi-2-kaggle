import ast
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import time
from .data import clean_task, digest
from .model import SYSTEM, DUCK_SYSTEM, extract_program, extract_action
from .verifier import verify


@dataclass
class SearchConfig:
    mode: str = 'synthesis'
    candidates: int = 4
    repairs: int = 1
    task_seconds: float = 240
    executor_seconds: float = 5
    diversity: bool = True
    stop_on_first: bool = False
    max_explorations: int = 2
    seed: int = 0


def code_identity(source):
    try:
        return hashlib.sha256(ast.dump(ast.parse(source), include_attributes=False).encode()).hexdigest()
    except SyntaxError:
        return hashlib.sha256(source.encode()).hexdigest()


def select(archive, task, diversity=True):
    """Select two different *outputs*, not merely two different source strings.
    Groups are voted by independent root lineage; repairs never inflate votes.
    Selection uses training fit and prediction agreement, never test truth.
    """
    predictions = []
    for index, test in enumerate(task['test']):
        groups = {}
        for c in archive:
            if not c.get('outputs') or c['outputs'][index] is None:
                continue
            value = c['outputs'][index]
            groups.setdefault(digest(value), []).append(c)
        def rank(group):
            exact = [c for c in group if c['verification']['exact']]
            pool = exact or group
            return (bool(exact), max(c['verification']['fit'] for c in pool),
                    len({c['root'] for c in pool}),
                    max(c['verification']['cell_accuracy'] for c in pool),
                    -min(c['complexity'] for c in pool))
        ordered = sorted(groups.values(), key=rank, reverse=True)
        if ordered:
            first = ordered[0][0]['outputs'][index]
            second = ordered[1][0]['outputs'][index] if diversity and len(ordered)>1 else first
        else:
            # Transparent emergency fallback; never described as a verified solution.
            first, second = test['input'], [[0]]
        predictions.append({'attempt_1': first, 'attempt_2': second})
    return predictions


class Solver:
    def __init__(self, model, executor, config=None):
        self.model, self.executor, self.config = model, executor, config or SearchConfig()

    def solve(self, task_id, task, outdir, deadline=None):
        task = clean_task(task)
        start = time.monotonic()
        deadline = min(deadline or float('inf'), start+self.config.task_seconds)
        folder = Path(outdir)/task_id
        folder.mkdir(parents=True, exist_ok=True)
        (folder/'task.json').write_text(json.dumps(task))
        archive, calls, seen = [], [], set()
        root_count, repair_count, proposal_count = 0, 0, 0
        stop = False
        for branch in range(self.config.candidates):
            if deadline-time.monotonic() < 1 or stop:
                break
            root_count += 1
            messages = [{'role': 'system', 'content': DUCK_SYSTEM if self.config.mode=='duck' else SYSTEM},
                        {'role': 'user', 'content': json.dumps(task, separators=(',', ':'))+
                         '\nIndependent hypothesis branch '+str(branch)+'. Infer the complete rule.'}]
            parent, previous_fit, stagnation, explores = None, -1, 0, 0
            generation = 0
            while generation <= self.config.repairs:
                if deadline-time.monotonic() < 1:
                    break
                try:
                    remaining=deadline-time.monotonic()
                    model_budget=remaining-min(2*self.config.executor_seconds,remaining*.2)
                    response = self.model.generate(messages, model_budget)
                except Exception as exc:
                    calls.append({'error':type(exc).__name__,'detail':str(exc)[:500],
                                  'branch':branch,'repair':generation,'messages':messages[:],
                                  'requested_wall_seconds':model_budget})
                    break
                call = dict(response,messages=messages[:],branch=branch,repair=generation,
                            requested_wall_seconds=model_budget)
                calls.append(call)
                text = response['text']
                messages.append({'role':'assistant', 'content':text})
                if self.config.mode=='duck' and explores < self.config.max_explorations:
                    action = extract_action(text)
                    if action.get('action')=='explore' and isinstance(action.get('code'), str):
                        scratch = 'TASK = '+repr(task)+'\n'+action['code']
                        execution = self.executor.run(scratch, [], mode='explore',
                            timeout=min(self.config.executor_seconds, max(.05, deadline-time.monotonic())))
                        call['exploration'] = execution
                        messages.append({'role':'user', 'content':'Python observation: '+json.dumps(execution)+
                                         ('\nExploration budget is exhausted; now return the final Python program.'
                                          if explores+1>=self.config.max_explorations else '')})
                        explores += 1
                        continue
                cid = f'b{branch:02d}-r{generation:02d}'
                proposal_count += 1
                candidate = {'id':cid, 'root':branch, 'parent':parent, 'repair':generation,
                             'response_index': len(calls)-1}
                generation += 1
                if parent is not None:
                    repair_count += 1
                try:
                    source = extract_program(text)
                except ValueError as exc:
                    candidate.update(source='', complexity=10**9, outputs=None,
                        verification={'exact':False,'fit':0,'cell_accuracy':0,'failure':'parse_error','detail':str(exc)})
                    archive.append(candidate)
                    messages.append({'role':'user','content':'No complete program was found. Emit final fenced Python defining solve(grid). Your last generation may have exhausted its token budget.'})
                    parent = cid
                    continue
                candidate['source'] = source
                identity = code_identity(source)
                candidate['code_hash'] = identity
                if identity in seen:
                    call['duplicate_code'] = identity
                    break
                seen.add(identity)
                try:
                    candidate['complexity'] = sum(1 for _ in ast.walk(ast.parse(source)))
                except SyntaxError:
                    candidate['complexity'] = 10**9
                inputs = [p['input'] for p in task['train']]
                execution = self.executor.run(source, inputs,
                    timeout=min(self.config.executor_seconds, max(.05, deadline-time.monotonic())))
                verification = verify(execution, task['train'])
                candidate.update(verification=verification, execution=execution, outputs=None)
                if deadline-time.monotonic() > .1:
                    test_execution = self.executor.run(source, [p['input'] for p in task['test']],
                        timeout=min(self.config.executor_seconds, max(.05, deadline-time.monotonic())))
                    candidate['test_execution'] = test_execution
                    if not test_execution.get('error'):
                        candidate['outputs'] = [p.get('output') for p in test_execution['results']]
                archive.append(candidate)
                (folder/(cid+'.py')).write_text(source)
                parent = cid
                if verification['exact']:
                    if self.config.stop_on_first and candidate['outputs'] and all(candidate['outputs']):
                        stop = True
                    # After a fit, use fresh branches to preserve independent hypotheses.
                    break
                fit = verification['fit'] + verification['cell_accuracy']*.01
                stagnation = stagnation+1 if fit <= previous_fit else 0
                previous_fit = max(previous_fit, fit)
                if stagnation >= 2:
                    break
                feedback = {'verification':verification, 'instruction':
                    'Use the counterexample to reconsider the rule, fix the program, and return the complete replacement. Do not special-case a training grid.'}
                # Compact repair context keeps the examples, most recent code and exact failure.
                messages = messages[:2]+[{'role':'assistant','content':'```python\n'+source+'\n```'},
                                         {'role':'user','content':json.dumps(feedback)}]
        predictions = select(archive, task, self.config.diversity)
        summary = {'task_id':task_id, 'config':asdict(self.config), 'task_hash':digest(task),
                   'seconds':time.monotonic()-start, 'generated_candidates':proposal_count,
                   'archived_candidates':len(archive), 'unique_programs':len(seen),
                   'duplicate_programs':sum(bool(c.get('duplicate_code')) for c in calls),
                   'root_branches':root_count, 'repair_iterations':repair_count,
                   'model_calls':len(calls), 'train_exact':any(c['verification']['exact'] for c in archive),
                   'predictions':predictions, 'archive':archive,
                   'failures':([c['verification']['failure'] for c in archive if c['verification']['failure']]+
                               ['generation_'+c['error'] for c in calls if c.get('error')]+
                               ['truncated_generation' for c in calls if c.get('finish_reason') in ('length','deadline','response_limit')])}
        (folder/'calls.json').write_text(json.dumps(calls, indent=2))
        (folder/'result.json').write_text(json.dumps(summary, indent=2))
        return summary
