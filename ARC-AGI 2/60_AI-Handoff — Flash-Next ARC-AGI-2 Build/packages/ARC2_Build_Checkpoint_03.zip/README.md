# ARC-AGI-2 executable-program induction

This checkpoint contains executable source, tests, frozen public data/references,
Kaggle notebooks, runtime bootstraps and chronological evidence. The root
RESEARCH_LOG.md and experiments/gpu-budget.json are authoritative for progress.
No benchmark number is implied by the presence of a notebook or passing fixture test.

## Local harness

Linux, libseccomp.so.2, Python with NumPy2.3.5. No Torch/vLLM required for the core.

```bash
cd code
python -m pip install -r requirements.txt
PYTHONPATH=. python -m unittest discover -s tests -v
PYTHONPATH=. python -m arcsolver.cli \
  --tasks /path/to/ARC-AGI-2/data/evaluation \
  --config configs/A1-one-program.json --subset 12 \
  --url http://127.0.0.1:8000/v1 --budget 3600 --out ../experiments/local-A1
```

A local OpenAI-compatible model server must already be running. The selected
config controls model name, thinking, output-token budget and search policy.
Use A4-search-repair.json or duck-generic.json for explicit comparison, not as
an assumed improvement. Duck mode is a generic bounded Python exploration loop
with fresh processes; it is not a full persistent Duck REPL reproduction.

Each candidate defines `solve(grid)`. Training pairs are checked exactly. Every
grid executes in a fresh process under mandatory Linux seccomp and memory/CPU/wall
limits. Missing isolation support fails closed. Candidate source, lineage,
counterexamples, full model responses/usage and selected predictions are archived.
Labels from test outputs are removed at task loading and never reach search.

## Evaluation

Frozen 4/12/120 task manifests are in experiments. Selection is stratified by
training input size/shape, seed20261024, with no test-label selection. Scores are
exact per-test-output two-attempt accuracy (not sampling-estimator pass@k).
The evaluator reports completed and scheduled denominators separately, training
fit, conditional train-to-test generalization, verified correct outputs, candidate
counts, repair iterations, failures and GPU device-hours. CPU fixtures have null
GPU efficiency. GPU device-hours mean elapsed wall hours times device count.
Partial runs, truncated generations and model errors must remain visible.

## Offline Kaggle inputs

27B: `rahim3/qwen3-8-27b-bf16`,
`saltb0x/arc3-vllm-wheelhouse-v0271-cu129`.

Flash: `dfranzen/albucino-qwen3.8-flash-next-w4a16-fp8ple/transformers/default/1`,
`foysalemonshanto/vllm-0-30-0-runtime`.

Both attach completed kernel output `liangwanyiudavid/arc2-runtime-builder` for
the exact standalone CPython3.12 archive. Current default Kaggle host is3.13;
using host Python with cp312 wheels is a demonstrated failure. Flash cannot use
vLLM0.27.1 because that registry lacks Qwen4Exp.

The generated notebooks embed the harness source. Ordinary CPU commits run
audits and optional runtime preflights, and do not create model benchmark scores.
GPU validation requires explicit guarded push. Real competition reruns detect
KAGGLE_IS_COMPETITION_RERUN, use all hidden test tasks and the 12-hour envelope,
and update `/kaggle/working/submission.json` atomically after every task.
If no GPU/model is available, a competition rerun fails rather than submitting
fixture predictions. No competition submission is justified by CPU audit alone.

## GPU quota

All discretionary validation runs together must reserve less than7200 seconds;
the enforced cap is6900. Even failed pushes/runs retain their full reservation.
Use scripts/push_kaggle.py with the shared ledger. Do not bypass it for retries.
Final ordinary commits are CPU-only. Official LB scores, if any, must be logged
with exact notebook version, source hash and submission ID.

## Provenance

New orchestration is MIT-0. Source snapshots retain their own licences and notices;
see references/SOURCE_CATALOG.json. Flash model weights remain under Qwen Community
License1.0. Large public model/runtime attachments are pinned by resource/version
and manifest; they are not duplicated into this ZIP. The Python interpreter bytes
and all material downloaded locally are included. Credentials are excluded.
