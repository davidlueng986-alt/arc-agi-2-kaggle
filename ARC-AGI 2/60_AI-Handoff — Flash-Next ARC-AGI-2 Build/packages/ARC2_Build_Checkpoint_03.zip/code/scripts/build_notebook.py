import argparse
import json
from pathlib import Path
import hashlib

p=argparse.ArgumentParser();p.add_argument('--target',choices=['27b','flash'],required=True)
p.add_argument('--seconds',type=int,required=True);p.add_argument('--slug',required=True)
p.add_argument('--backend',default='vllm');p.add_argument('--gpu',action='store_true')
p.add_argument('--preflight-layers',action='store_true')
p.add_argument('--subset',type=int,default=4)
a=p.parse_args()
root=Path(__file__).parents[1]
files={str(f.relative_to(root)):f.read_text() for folder in ['arcsolver','tests','configs'] for f in (root/folder).rglob('*') if f.is_file() and '__pycache__' not in str(f)}
blob=json.dumps(files,separators=(',',':'))
bootstrap='''from pathlib import Path
import sys,json
root=Path('/kaggle/working/arc2-code');root.mkdir(exist_ok=True)
files=json.loads(BLOB)
for name,content in files.items():
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
sys.path.insert(0,str(root))
'''.replace('BLOB',repr(blob))
run={'target':a.target,'backend':a.backend,'hard_seconds':a.seconds,'subset':a.subset,
     'preflight_layers':a.preflight_layers,
     'source_sha256':hashlib.sha256(blob.encode()).hexdigest()}
entry='from arcsolver.kaggle_runtime import main\nmain('+repr(run)+')'
nb={'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'}},
    'cells':[{'cell_type':'markdown','metadata':{},'source':['# ARC2 executable-program induction\nCPU commits run the audit suite. GPU validation is hard-bounded. No fixture predictions are submitted.']},
             *[{'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':s.splitlines(True)} for s in [bootstrap,entry]]]}
for i,cell in enumerate(nb['cells']):cell['id']='arc2-cell-'+str(i)
out=root/'kaggle'/a.slug;out.mkdir(parents=True,exist_ok=True)
(out/'solver.ipynb').write_text(json.dumps(nb))
meta={'id':'liangwanyiudavid/'+a.slug,'title':a.slug.replace('-',' '),'code_file':'solver.ipynb',
      'language':'python','kernel_type':'notebook','is_private':True,'enable_gpu':a.gpu,
      'enable_internet':False,'competition_sources':['arc-prize-2026-arc-agi-2'],
      'dataset_sources':['saltb0x/arc3-vllm-wheelhouse-v0271-cu129'],
      'model_sources':[],'kernel_sources':[],'enable_tpu':False}
if a.target=='27b':meta['dataset_sources'].append('rahim3/qwen3-8-27b-bf16')
else:
    meta['dataset_sources']=['foysalemonshanto/vllm-0-30-0-runtime']
    meta['model_sources']=['dfranzen/albucino-qwen3.8-flash-next-w4a16-fp8ple/transformers/default/1']
meta['kernel_sources'].append('liangwanyiudavid/arc2-runtime-builder')
(out/'kernel-metadata.json').write_text(json.dumps(meta,indent=2))
print(out)
