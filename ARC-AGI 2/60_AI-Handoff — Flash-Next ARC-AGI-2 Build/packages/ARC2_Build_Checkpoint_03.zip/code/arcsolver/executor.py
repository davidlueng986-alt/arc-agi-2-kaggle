import json
import os
from pathlib import Path
import subprocess
import selectors
import signal
import sys
import tempfile
import time


class Executor:
    def __init__(self, timeout=5, memory_mb=768):
        self.timeout, self.memory_mb = timeout, memory_mb

    def run(self, source, inputs, timeout=None, mode='solve'):
        start = time.monotonic()
        if mode=='solve' and len(inputs)>1:
            results, observations = [], []
            budget=timeout or self.timeout
            for value in inputs:
                remaining=budget-(time.monotonic()-start)
                if remaining<.05:
                    results.append({'error':'timeout','detail':'batch execution deadline'})
                    continue
                item=self.run(source,[value],timeout=remaining)
                if item.get('error'):
                    results.append({'error':item['error'],'detail':item.get('detail','')})
                else:results.extend(item['results'])
                observations.append(item.get('stdout',''))
            return {'results':results,'stdout':'\n'.join(observations)[:8192],
                    'seconds':time.monotonic()-start,'sandbox':'one-seccomp-process-per-grid'}
        if len(source) > 100000:
            return {'error': 'source_too_long', 'seconds': 0}
        env = {'PATH': '/usr/bin:/bin', 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
               'MKL_NUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1'}
        payload = {'source': source, 'inputs': inputs, 'memory_mb': self.memory_mb,
                   'cpu_seconds': max(1, int(timeout or self.timeout)), 'mode': mode}
        try:
            # Bound parent memory even if code bypasses redirected print using
            # os.write/sys.__stdout__. A child memory limit alone is insufficient.
            with tempfile.TemporaryFile() as inp:
                inp.write(json.dumps(payload).encode());inp.seek(0)
                proc=subprocess.Popen([sys.executable,'-I',str(Path(__file__).with_name('worker.py'))],
                    stdin=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,
                    close_fds=True,cwd='/tmp',start_new_session=True)
                chunks={1:bytearray(),2:bytearray()};failure=None
                deadline=start+max(.05,timeout or self.timeout)
                with selectors.DefaultSelector() as selector:
                    selector.register(proc.stdout,selectors.EVENT_READ,1)
                    selector.register(proc.stderr,selectors.EVENT_READ,2)
                    while selector.get_map():
                        remaining=deadline-time.monotonic()
                        if remaining<=0:failure='timeout';break
                        for key,_ in selector.select(min(.1,remaining)):
                            data=os.read(key.fileobj.fileno(),8192)
                            if not data:selector.unregister(key.fileobj);continue
                            chunks[key.data].extend(data)
                            if len(chunks[key.data])>(131072 if key.data==1 else 16384):
                                failure='output_limit';break
                        if failure:break
                if failure:
                    os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=1)
                    result={'error':failure}
                else:
                    try:proc.wait(timeout=max(.01,deadline-time.monotonic()))
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=1)
                        failure='timeout'
                    if failure:result={'error':failure}
                    elif proc.returncode:
                        result={'error':'worker_exit','returncode':proc.returncode,
                                'detail':chunks[2][-500:].decode(errors='replace')}
                    else:result=json.loads(chunks[1])
                proc.stdout.close();proc.stderr.close()
        except subprocess.TimeoutExpired:
            result = {'error': 'timeout'}
        except (ValueError, OSError) as exc:
            result = {'error': 'executor_error', 'detail': str(exc)[:500]}
        return dict(result, seconds=time.monotonic() - start)
