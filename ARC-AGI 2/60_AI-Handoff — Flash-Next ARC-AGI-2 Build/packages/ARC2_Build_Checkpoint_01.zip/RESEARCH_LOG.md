# ARC-AGI-2 — chronological research/build log

All timestamps HKT (UTC+8). Existing parent documents are read-only; all new outputs remain in the specified 60_AI-Handoff folder. No historical score in the background documents is treated as a new measured result.

## R00 — 2026-10-24 — takeover/source freeze
Read 00_INDEX, 01_BACKGROUND, 02_RESEARCH_OBJECTIVE, 03_RESEARCH_LOG. The destination was empty. Created code, experiments, traces, references, models-runtime-notes, packages. Downloaded four source documents verbatim. Credential document retrieved into private temporary storage, never included in deliverables. Kaggle Bearer token successfully authenticated; username liangwanyiudavid. No unrelated credentials used.

Frozen sources: official ARC-AGI-2 f3283f727488ad98fe575ea6a5ac981e4a188e49; Duck 7652836056c59e044f093e3c13ed7438c814169e (source/notebook snapshot, excluding unrelated 500-game ARC3 trace corpus); OpenKaggle research 7c401c25edb9914033725691f9189bd9bc531892. Source manifest and hashes retained. Public vanilla-exact API pull failed with 403; NVARC/TRM evidence notebook pulled successfully. Also pulled user's previous H3 code-verifier notebook: it has CPU fallback MockLLM, which is infrastructure evidence only and cannot substantiate Qwen accuracy. New CPU audit never reports fixture output as a model result.

Decision: use pure Python programs and fresh per-input execution; keep both generic exploration and explicit search as configurable tracks. No giant DSL. Original model policy retained.

## R01 — executor bring-up
Implemented Linux seccomp worker, resource limits, no credentials/environment inheritance, no filesystem opens, network creation/connect or process creation after library preload. First run failed closed: setgroups/setuid unavailable in this rootless single-UID namespace. Corrected by verifying single-user UID mapping before retaining namespace UID; on normal rootful hosts UID drop remains mandatory. Retried identity and NumPy rotation: exact expected results. /etc/passwd access returned PermissionError. Infinite loop stopped at 2.0s wall timeout. Evidence: unit-tests-01.txt and tests/test_system.py. This is infrastructure validation, not a model benchmark.

## R02 — harness implementation
Implemented loader with test-label firewall; exact all-pair verifier with dimension/cell/colour feedback; generated-code parser excludes reasoning channel; isolated executor; multi-root candidate/repair lineage; AST dedup; train-fit-first selection; output grouping counts independent roots only; two output diversity; stagnation and deadline stopping; atomic submission persistence; per-output exact pass@1/pass@2; conditional verified generalization; failures/candidates/repairs/runtime; GPU device-hour accounting. Full public task labels enter evaluator only after prediction selection.

Both generic exploration (fresh bounded Python observations, no persistent REPL) and explicit synthesis supported. No claim that this is an exact Duck reproduction. Simplicity and support-ranking are provisional heuristics, not established improvements. Neural ablations not yet measured at this checkpoint.

## G01 — Qwen3.8-27B real GPU bring-up (requested)
Config: official-model BF16 Kaggle mirror rahim3/qwen3-8-27b-bf16; offline wheelhouse saltb0x/arc3-vllm-wheelhouse-v0271-cu129; vLLM 0.27.1, TP4, context 16384, eager, max_num_seqs=2, memory utilization .88, reasoning parser qwen3. Medium thinking; smoke 4096 output tokens then 8192-token task calls. Four fixed stratified public-eval tasks selected without test labels, seed 20261024. A1 one candidate/no repair first, A4 two roots/one repair if time remains. Unequal/insufficient realized token budgets must be reported; this small run can validate integration but cannot establish a reliable architectural gain.
Requested Kaggle NvidiaL4, API timeout 1500 seconds. Independent in-notebook watchdog exits at 1480 seconds. Full 1500 seconds reserved in GPU ledger even if run fails early. No later GPU request may exceed cumulative 6900 seconds (<7200). After validation final commits are CPU-only. Status/metrics pending; no pass score asserted.
