"""Offline Kaggle entry point; CPU commits audit only, never impersonate a model."""
import glob
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
import urllib.request
from .data import load_tasks, fixed_subset, digest
from .evaluate import atomic_json, run_evaluation, validate_submission
from .executor import Executor
from .model import OpenAIModel
from .search import Solver, SearchConfig


def gpu_info():
    try:
        p=subprocess.run(['nvidia-smi','--query-gpu=name,memory.total,memory.used','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
        return p.stdout.strip().splitlines() if p.returncode==0 else []
    except OSError:return []


def main(run):
    run=dict(run)
    competition_rerun=os.environ.get('KAGGLE_IS_COMPETITION_RERUN','').lower() in ('1','true')
    if competition_rerun:
        run.update(hard_seconds=42600,phase='submission')
    start=time.monotonic()
    work=Path('/kaggle/working');work.mkdir(exist_ok=True)
    report=work/'arc2-results';report.mkdir(exist_ok=True)
    gpus=gpu_info();server=None
    state={'run':run,'gpus':gpus,'status':'starting','peak_vram_mib':{},'started_epoch':time.time()}
    atomic_json(report/'runtime.json',state)
    def watch():
        while time.monotonic()-start < run['hard_seconds']-20:
            for i,line in enumerate(gpu_info()):
                try:state['peak_vram_mib'][str(i)]=max(state['peak_vram_mib'].get(str(i),0),int(line.split(',')[-1]))
                except ValueError:pass
            state['elapsed_seconds']=time.monotonic()-start
            atomic_json(report/'runtime.json',state)
            time.sleep(5)
        state['status']='hard_deadline';atomic_json(report/'runtime.json',state)
        if server:
            try:os.killpg(server.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        os._exit(124)
    threading.Thread(target=watch,daemon=True).start()
    print(json.dumps(state),flush=True)
    if not gpus:
        if competition_rerun:
            raise RuntimeError('competition rerun has no GPU; refuse to submit fixture/fallback-only results')
        state['status']='cpu_audit_no_model_inference'
        # Use executable tests, not mock ARC predictions, to validate a CPU commit.
        cp=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(Path(__file__).parents[1]/'tests'),'-v'],capture_output=True,text=True)
        (report/'unit-tests.txt').write_text(cp.stdout+cp.stderr)
        state['unit_tests_returncode']=cp.returncode
        atomic_json(report/'runtime.json',state)
        print(json.dumps(state),flush=True)
        if cp.returncode:raise RuntimeError('CPU audit failed')
        return
    if len(gpus)!=4 or not all('L4' in x for x in gpus):
        raise RuntimeError('validation is pinned to L4x4, observed '+repr(gpus))
    inputs=Path('/kaggle/input')
    try:
        if run['backend']=='vllm':
            wheels=[p for p in inputs.rglob('vllm*.whl') if 'sm120' not in str(p)]
            if not wheels:raise RuntimeError('missing compatible offline vLLM wheelhouse')
            dirs=sorted({str(p.parent) for p in inputs.rglob('*.whl') if 'sm120' not in str(p)})
            cmd=[sys.executable,'-m','pip','install','--no-index']
            for d in dirs:cmd+=['--find-links',d]
            cmd += ['vllm==0.27.1']
            state['pip_command']=cmd
            with (report/'pip.log').open('w') as f:
                subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=min(420,run['hard_seconds']//3))
            model_dirs=[]
            for p in inputs.rglob('config.json'):
                try:
                    c=json.loads(p.read_text()); arch=c.get('model_type','')
                    if (run['target']=='27b' and arch.startswith('qwen3')) or (run['target']=='flash' and arch=='qwen4_exp'):
                        model_dirs.append(p.parent)
                except (OSError,ValueError):pass
            if not model_dirs:raise RuntimeError('model config not mounted')
            model_path=sorted(model_dirs)[0]
            cmd=[sys.executable,'-m','vllm.entrypoints.openai.api_server','--model',str(model_path),
                 '--served-model-name','arc-model','--host','127.0.0.1','--port','8000',
                 '--tensor-parallel-size','4','--max-model-len','16384','--max-num-seqs','2',
                 '--gpu-memory-utilization','0.88','--enforce-eager','--reasoning-parser','qwen3',
                 '--language-model-only']
            env=os.environ.copy();env['VLLM_PLE_CPU_OFFLOAD']='1'
            state['model_config']=json.loads((model_path/'config.json').read_text())
        else:
            bins=list(inputs.rglob('llama-server'))
            candidates=[p for p in inputs.rglob('*.gguf') if 'mmproj' not in p.name.lower() and 'mtp-' not in p.name.lower() and 'draft' not in p.name.lower()]
            candidates=[p for p in candidates if ('Flash' in p.name if run['target']=='flash' else '27B' in p.name)]
            if not bins or not candidates:raise RuntimeError('offline llama-server/model missing')
            binary=bins[0];os.chmod(binary,0o755)
            model_path=sorted(candidates)[0]
            cmd=[str(binary),'-m',str(model_path),'--alias','arc-model','--host','127.0.0.1','--port','8000',
                 '-ngl','999','--split-mode','layer','--tensor-split','1,1,1,1','-c','16384','-np','1',
                 '-b','512','-ub','128','--jinja','--override-tensor','per_layer_token_embd=CPU']
            env=os.environ.copy();env['LD_LIBRARY_PATH']=str(binary.parent)+':'+env.get('LD_LIBRARY_PATH','')
        state['server_command']=cmd;atomic_json(report/'runtime.json',state)
        log=(report/'server.log').open('w')
        server=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        ready_deadline=min(start+run['hard_seconds']-180,time.monotonic()+900)
        while time.monotonic()<ready_deadline:
            if server.poll() is not None:raise RuntimeError('server exited '+str(server.returncode))
            try:
                with urllib.request.urlopen('http://127.0.0.1:8000/v1/models',timeout=2) as r:
                    if r.status==200:break
            except Exception:time.sleep(3)
        else:raise RuntimeError('readiness deadline')
        state['status']='model_ready';state['startup_seconds']=time.monotonic()-start
        atomic_json(report/'runtime.json',state)
        # Smoke is a real generation and must produce final executable Python.
        model=OpenAIModel(backend=run['backend'],max_tokens=4096,reasoning_effort='medium')
        smoke=model.generate([{'role':'user','content':'Write only a fenced Python program defining solve(grid) that horizontally reverses each row. Keep reasoning brief.'}],min(150,run['hard_seconds']-(time.monotonic()-start)-30))
        atomic_json(report/'model-smoke.json',smoke)
        from .model import extract_program
        evidence=Executor().run(extract_program(smoke['text']),[[[1,2,3]]])
        atomic_json(report/'smoke-execution.json',evidence)
        if evidence.get('results') != [{'output':[[3,2,1]]}]:raise RuntimeError('real model smoke did not pass')
        split='test' if competition_rerun else 'evaluation'
        challenge=list(inputs.rglob('arc-agi_'+split+'_challenges.json'))
        if not challenge:raise RuntimeError('evaluation challenges missing')
        tasks,labels=load_tasks(challenge[0])
        sol=challenge[0].with_name('arc-agi_'+split+'_solutions.json')
        if sol.exists():labels=json.loads(sol.read_text())
        subset=list(tasks) if competition_rerun else fixed_subset(tasks,run.get('subset',4))
        tasks={k:tasks[k] for k in subset}
        atomic_json(report/'subset.json',{'ids':subset,'hash':digest(tasks),'selection':'shape/size stratified, seed 20261024, no test labels'})
        available=run['hard_seconds']-(time.monotonic()-start)-45
        if competition_rerun:
            solver=Solver(OpenAIModel(backend=run['backend'],max_tokens=16384,reasoning_effort='xhigh'),
                          Executor(),SearchConfig(candidates=6,repairs=2,task_seconds=600))
            run_evaluation(tasks,{},solver,report/'submission',available,gpu_count=4)
            final=json.loads((report/'submission/submission.json').read_text())
            validate_submission(final,tasks)
            atomic_json(work/'submission.json',final)
            state['status']='completed_submission'
            return
        # Small fixed A1 baseline first. Search/repair is measured only if time remains.
        for name,sc in [('A1',SearchConfig(candidates=1,repairs=0,task_seconds=120,stop_on_first=True,diversity=False)),
                        ('A4',SearchConfig(candidates=2,repairs=1,task_seconds=180))]:
            remaining=run['hard_seconds']-(time.monotonic()-start)-45
            if remaining<60:break
            budget=min(remaining, max(60,available*.45) if name=='A1' else remaining)
            solver=Solver(OpenAIModel(backend=run['backend'],max_tokens=8192,reasoning_effort='medium'),Executor(),sc)
            run_evaluation(tasks,labels,solver,report/name,budget,gpu_count=4)
        state['status']='completed';state['elapsed_seconds']=time.monotonic()-start
    except BaseException as exc:
        state['status']='failed';state['error']=type(exc).__name__+': '+str(exc)
        raise
    finally:
        state['elapsed_seconds']=time.monotonic()-start
        atomic_json(report/'runtime.json',state)
        if server:
            try:os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=10)
            except (ProcessLookupError,subprocess.TimeoutExpired):
                try:os.killpg(server.pid,signal.SIGKILL)
                except ProcessLookupError:pass
